# 🚀 Ratel Ocean 플랫폼 - 전체 기능 구현 로드맵

## 📊 현재 상태 (2026-01-18)

### ✅ 완료된 사항
1. **프리랜서/클라이언트 메인 페이지** - 프로필 정보 표시
   - `/freelancer/main` - 프리랜서 정보 표시 (닉네임, 자기소개, 학력, 포트폴리오, 계좌)
   - `/client/main` - 클라이언트 정보 표시 (이름, 이메일, 전화, 생년월일)

2. **헤더/푸터** - 당신이 만든 디자인 적용 완료
   - `freelancer_header.jsp` - 프리랜서 전용 상단바 (프로젝트 찾기, 내 프로젝트, 내 금융, 내 경력 등)
   - `client_header.jsp` - 클라이언트 전용 상단바 (프로젝트 찾기, 내 프로젝트, 채팅방 등)
   - `footer.jsp` - 공통 하단바

3. **회원가입 및 자동 로그인**
   - 프리랜서 회원가입 완료 → `/freelancer/main` 자동 이동
   - 클라이언트 회원가입 완료 → `/client/main` 자동 이동
   - 로그인 후 각자의 `/main` 페이지로 이동

---

## 🎯 다음 구현 단계

### **1단계: 헤더 기능 페이지 구현**

#### **1-1. 프리랜서 기능**

| 엔드포인트 | 기능 | 상태 | 페이지 |
|-----------|------|------|--------|
| `/project_dashboard` | 프로젝트 찾기 | ❌ 미구현 | 프로젝트 목록 |
| `/myproject` | 내 프로젝트 관리 | ❌ 미구현 | 지원한 프로젝트 목록 |
| `/mymoney` | 내 금융 관리 | ❌ 미구현 | 지갑, 수익 관리 |
| `/mycareer` | 내 경력 관리 | ❌ 미구현 | 경력, 포트폴리오 |
| `/notifications` | 알림 | ❌ 미구현 | 알림 목록 |
| `/chat` | 채팅 | ❌ 미구현 | 채팅방 목록 |
| `/myprofile` | 프로필 | ❌ 미구현 | 프로필 수정 |

#### **1-2. 클라이언트 기능**

| 엔드포인트 | 기능 | 상태 | 페이지 |
|-----------|------|------|--------|
| `/project_dashboard` | 프로젝트 찾기 | ❌ 미구현 | 프로젝트 목록 |
| `/myproject` | 내 프로젝트 관리 | ❌ 미구현 | 내 프로젝트 목록 |
| `/chat` | 채팅방 | ❌ 미구현 | 채팅방 목록 |
| `/myprofile` | 마이 프로필 | ❌ 미구현 | 프로필 수정 |
| `/notifications` | 알림 | ❌ 미구현 | 알림 목록 |

---

### **2단계: 대시보드 페이지**

| 페이지 | 용도 | 상태 |
|--------|------|------|
| `/freelancer/dashboard` | 프리랜서 대시보드 (지원 현황, 진행 프로젝트) | ❌ 미구현 |
| `/client/dashboard` | 클라이언트 대시보드 (내 프로젝트, 지원자 관리) | ❌ 미구현 |

---

## 🗂️ 파일 구조

```
src/main/webapp/WEB-INF/views/
├── freelancer/
│   ├── main.jsp ✅ (프로필 정보 표시)
│   ├── dashboard.jsp ❌
│   ├── project_dashboard.jsp ❌
│   ├── myproject.jsp ❌
│   ├── mymoney.jsp ❌
│   ├── mycareer.jsp ❌
│   ├── myprofile.jsp ❌
│   ├── notifications.jsp ❌
│   └── chat.jsp ❌
│
├── client/
│   ├── main.jsp ✅ (프로필 정보 표시)
│   ├── dashboard.jsp ❌
│   ├── project_dashboard.jsp ❌
│   ├── myproject.jsp ❌
│   ├── chat.jsp ❌
│   ├── myprofile.jsp ❌
│   └── notifications.jsp ❌
│
└── common/
    ├── freelancer_header.jsp ✅
    ├── client_header.jsp ✅
    └── footer.jsp ✅
```

---

## 🛠️ 데이터베이스 관련 정보

### 프리랜서 정보 조회
```java
// FreelancerMapper
FreelancerProfile findByUserId(Long userId)

// 반환되는 필드
- userId
- nickname
- introduction
- githubUrl
- websiteUrl
- schoolName
- major
- degree
- gradStatus
- isProfileComplete
```

### 프리랜서 기술 스택 조회
```java
// FreelancerMapper
List<FreelancerSkill> getFreelancerSkills(Long freelancerId)

// 테이블: freelancer_skills
- freelancer_stack_id (PK)
- freelancer_id (FK)
- stack_id (FK)
- stack_level (1-5)
- stack_year
```

### 클라이언트 정보
```java
// User 객체에서
- name
- email
- phone
- birthDate
- userType (CLIENT/FREELANCER)
```

---

## 💡 구현 팁

### 1. 페이지 간 데이터 전달
- **Model 사용**: `model.addAttribute("key", value)`
- **EL 표현식**: `${key}`
- **세션 사용**: `${sessionScope.loginUser.name}`

### 2. 프리랜서/클라이언트 구분
```jsp
<%
    Object userObj = session.getAttribute("loginUser");
    // 또는 Model에서 ${loginUser.userType}
%>
```

### 3. 조건부 표시
```jsp
<c:if test="${freelancerProfile.nickname != null}">
    <!-- 정보가 있을 때 -->
</c:if>
<c:if test="${freelancerProfile.nickname == null}">
    <span class="empty">미입력</span>
</c:if>
```

---

## 🎨 스타일링 가이드

### 이미 만들어진 색상
- **주색**: `#1F7A8C` (터콜)
- **부색**: `#94D9DB` (라이트 터콜)
- **배경**: `#F5F5F5` (라이트 그레이)
- **텍스트**: `#2B2B2B` (다크 차콜)

### 카드 스타일
```css
.info-card { 
    background: #f9f9f9; 
    border-left: 4px solid #1F7A8C; 
    padding: 1.5rem; 
    border-radius: 6px; 
}
```

---

## 📝 다음 작업 체크리스트

- [ ] 1-1. `/project_dashboard` 프로젝트 목록 페이지
- [ ] 1-2. `/myproject` 내 프로젝트 관리 페이지
- [ ] 1-3. `/mymoney` 내 금융 관리 페이지 (프리랜서)
- [ ] 1-4. `/mycareer` 내 경력 관리 페이지
- [ ] 1-5. `/chat` 채팅 페이지
- [ ] 1-6. `/notifications` 알림 페이지
- [ ] 1-7. `/myprofile` 프로필 수정 페이지
- [ ] 2-1. 프리랜서 대시보드 페이지
- [ ] 2-2. 클라이언트 대시보드 페이지

---

## 🚀 빌드 및 배포

```bash
# 빌드
mvn clean package -DskipTests

# Tomcat 시작
./catalina.bat run (Windows)
./catalina.sh run (Linux/Mac)

# 포트
http://localhost:9999/ratelocean/
```

---

## 🔗 주요 컨트롤러

### FreelancerController
- 위치: `/src/main/java/.../freelancer/controller/`
- 주요 메서드:
  - `main()` - GET /freelancer/main
  - `dashboard()` - GET /freelancer/dashboard
  - `completeProfile()` - GET/POST /freelancer/complete-profile.do

### ProjectController
- 위치: `/src/main/java/.../project/controller/`
- 주요 메서드:
  - `clientMain()` - GET /client/main
  - `projectDashboard()` - GET /project/dashboard

---

작성일: 2026-01-18
마지막 업데이트: 2026-01-18
