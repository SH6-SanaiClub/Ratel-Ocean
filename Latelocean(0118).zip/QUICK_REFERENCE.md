# ⚡ 개발 환경 빠른 참조 (Quick Reference)

## 🚀 서버 시작 명령어

### PowerShell에서 (모든 환경변수 설정)
```powershell
$env:JAVA_HOME = "C:\program\jdk-11.0.22+7"
$env:M2_HOME = "C:\program\apache-maven-3.9.6"
$env:CATALINA_HOME = "C:\program\apache-tomcat-9.0.112"
$env:Path = "$env:JAVA_HOME\bin;$env:M2_HOME\bin;$env:CATALINA_HOME\bin;" + $env:Path

# MySQL 시작
Start-Service MySQL80

# Tomcat 시작
& "$env:CATALINA_HOME\bin\catalina.bat" run
```

### 또는 배치 파일로 저장 (run-dev-env.bat)
```batch
@echo off
set JAVA_HOME=C:\program\jdk-11.0.22+7
set M2_HOME=C:\program\apache-maven-3.9.6
set CATALINA_HOME=C:\program\apache-tomcat-9.0.112
set PATH=%JAVA_HOME%\bin;%M2_HOME%\bin;%CATALINA_HOME%\bin;%PATH%

echo Starting MySQL...
net start MySQL80

echo.
echo Starting Tomcat...
cd /d "%CATALINA_HOME%\bin"
catalina.bat run

pause
```

---

## 📋 환경변수 설정 현황

| 변수 | 값 | 상태 |
|------|-----|------|
| JAVA_HOME | C:\program\jdk-11.0.22+7 | ✅ 설정됨 |
| M2_HOME | C:\program\apache-maven-3.9.6 | ✅ 설정됨 |
| CATALINA_HOME | C:\program\apache-tomcat-9.0.112 | ✅ 설정됨 |
| MySQL PATH | C:\Program Files (x86)\MySQL\MySQL Server 8.0\bin | ⚠️ MySQL 설치 후 |

---

## 🔧 자주 사용하는 명령어

### Java
```bash
java -version                    # Java 버전 확인
javac -version                   # Compiler 버전 확인
```

### Maven
```bash
mvn -version                     # Maven 버전 확인
mvn clean compile                # 빌드 (컴파일만)
mvn clean package                # WAR 파일 생성
mvn clean package -DskipTests    # 테스트 건너뛰고 빌드
mvn dependency:tree              # 의존성 트리 확인
```

### Tomcat
```bash
catalina.bat run                 # 포그라운드 실행 (권장)
catalina.bat start               # 백그라운드 실행
catalina.bat stop                # 서버 중지
```

### MySQL
```bash
mysql -h localhost -u root -p0000                  # MySQL 접속
mysql -h localhost -u root -p0000 -e "SELECT 1;"  # 연결 테스트
mysql -h localhost -u root -p0000 sanai < dump.sql # 덤프 복원
```

---

## 📁 주요 파일 위치

| 파일/폴더 | 경로 |
|----------|------|
| **프로젝트 루트** | C:\Users\김재환\Desktop\Latelocean\Latelocean |
| **소스 코드** | src/main/java/com/sanaiclub |
| **JSP 페이지** | src/main/webapp/WEB-INF/views |
| **설정 파일** | src/main/resources/spring |
| **DB 설정** | src/main/resources/db.properties |
| **pom.xml** | Latelocean\pom.xml |
| **WAR 파일** | target\ratelocean.war |
| **Tomcat** | C:\program\apache-tomcat-9.0.112 |
| **MySQL Installer** | C:\Program Files (x86)\MySQL\MySQL Installer for Windows |
| **DB 덤프** | C:\program\sanaidump.sql |

---

## 🌐 서비스 URL

| 서비스 | URL | 포트 |
|--------|-----|------|
| **메인 페이지** | http://localhost:9999/ratelocean/ | 9999 |
| **회원가입 (역할선택)** | http://localhost:9999/ratelocean/join/select-role.do | 9999 |
| **프리랜서 회원가입** | http://localhost:9999/ratelocean/join/freelancer | 9999 |
| **로그인** | http://localhost:9999/ratelocean/login | 9999 |
| **프로필 완성** | http://localhost:9999/ratelocean/freelancer/complete-profile | 9999 |
| **MySQL** | localhost:3306 | 3306 |
| **Tomcat Manager** | http://localhost:9999/manager | 9999 |

---

## 🎯 빌드 및 배포 프로세스

### 1단계: 빌드
```bash
cd C:\Users\김재환\Desktop\Latelocean\Latelocean
mvn clean package -DskipTests
```

### 2단계: WAR 파일 배포
```bash
copy target\ratelocean.war C:\program\apache-tomcat-9.0.112\webapps\
```

### 3단계: Tomcat 재시작
```bash
# 기존 서버 중지 (Ctrl+C)
# 새로 시작
catalina.bat run
```

### 4단계: 검증
```bash
# 브라우저에서 http://localhost:9999/ratelocean/ 접속
# 로그에서 "Root WebApplicationContext initialized" 확인
```

---

## 📊 버전 호환성

```
JDK 11.0.22 (OpenJDK Temurin)
├─ Spring Framework 5.3.33
├─ Spring JDBC
├─ Spring Context
└─ Spring Web MVC

MyBatis 3.5.13
├─ MyBatis Spring 2.1.1
├─ MySQL Connector/J 8.0.33
└─ HikariCP 4.0.3

Servlet/JSP
├─ Servlet API 4.0.1
├─ JSP API 2.3.3
└─ JSTL 1.2

Build
├─ Maven 3.9.6
├─ Java Compiler Target: 11
└─ Encoding: UTF-8

Web Container
├─ Tomcat 9.0.112
└─ Port: 9999
```

---

## ⚙️ 자주 발생하는 문제 및 해결

### Q1: "java: command not found"
```bash
# 해결: Java PATH 설정
$env:Path = "C:\program\jdk-11.0.22+7\bin;" + $env:Path
java -version
```

### Q2: "mvn: command not found"
```bash
# 해결: Maven PATH 설정
$env:Path = "C:\program\apache-maven-3.9.6\bin;" + $env:Path
mvn -version
```

### Q3: "Port 9999 is already in use"
```bash
# 현재 사용 중인 프로세스 찾기
netstat -ano | findstr 9999

# 프로세스 강제 종료 (PID: 12345)
taskkill /PID 12345 /F
```

### Q4: "MySQL access denied"
```bash
# MySQL 비밀번호 확인: db.properties의 db.password=0000
# 사용자명: remote_user

# 테스트 연결
mysql -h localhost -u remote_user -p0000 -e "SELECT 1;"
```

### Q5: "WAR 파일이 배포되지 않음"
```bash
# Tomcat webapps 폴더 확인
dir C:\program\apache-tomcat-9.0.112\webapps\

# 파일이 없으면 수동 복사
copy target\ratelocean.war C:\program\apache-tomcat-9.0.112\webapps\
```

---

## 🔐 보안 기본값 (개발 환경용)

⚠️ **프로덕션에서는 변경 필수**

```
MySQL Root 비밀번호: 0000
MySQL User (remote_user) 비밀번호: 0000
Wallet 기본 비밀번호: 0000
User 비밀번호 저장: 평문 (해시 필요)
```

---

## 📞 도움말

### 로그 위치
```
Tomcat 콘솔: 터미널 출력
Tomcat 파일 로그: C:\program\apache-tomcat-9.0.112\logs\

Spring 로그: logback.xml 설정
MyBatis 로그: root-context.xml에서 설정
```

### 설정 파일
```
Spring 설정: src/main/resources/spring/
  ├─ root-context.xml (Bean, DataSource, MyBatis)
  └─ servlet-context.xml (View Resolver, HandlerMapping)

Web 설정: src/main/webapp/WEB-INF/
  ├─ web.xml (Servlet, Filter, Listener)
  └─ views/ (JSP 페이지들)

DB 설정: src/main/resources/
  ├─ db.properties (연결 정보)
  ├─ mybatis/
  │  ├─ mybatis-config.xml
  │  └─ mappers/ (SQL 매핑)
  └─ logback.xml (로깅)
```

---

## 🎓 학습 리소스

- [Spring Framework Documentation](https://spring.io/projects/spring-framework)
- [MyBatis Guide](https://mybatis.org/mybatis-3/)
- [Tomcat Documentation](https://tomcat.apache.org/)
- [MySQL Documentation](https://dev.mysql.com/doc/)
- [Maven Getting Started](https://maven.apache.org/guides/getting-started/)

---

**최종 준비 상태: 90%** (MySQL만 설치하면 100%)

마지막 단계: [MYSQL_SETUP_GUIDE.md](MYSQL_SETUP_GUIDE.md) 참조
