# 📱 전화번호 인증 시스템 구현 가이드

## 개요

이 문서는 Mock 기반 전화번호 인증 시스템의 전체 구현을 설명합니다. 유료 SMS API 없이 로컬 개발 환경에서 테스트 가능하도록 설계되었습니다.

---

## 1️⃣ 시스템 구조

### 아키텍처

```
┌─────────────────────────────────────────────────────────────────┐
│                   Signup Page (signup.jsp)                      │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │ Phone Input (010-1234-5678)                                │ │
│  │      ↓                                                      │ │
│  │ Send Code Button → [Click] → Verification Code Generated   │ │
│  │      ↓                                                      │ │
│  │ Verify Area (Hidden by default)                            │ │
│  │ ├─ Verify Code Input (인증번호 6자리)                      │ │
│  │ ├─ Verify Button                                           │ │
│  │ └─ Timer (5:00 → 0:00)                                     │ │
│  │      ↓                                                      │ │
│  │ Validation.phoneVerified = true                            │ │
│  │ → Next Button 활성화                                        │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                 │
│ JavaScript State Management: phoneAuthState {}                 │
│ ├─ currentPhone: '010-1234-5678'                              │
│ ├─ verificationCode: '123456'                                 │
│ ├─ timeRemaining: 300 (seconds)                               │
│ ├─ isCodeSent: boolean                                        │
│ └─ isVerified: boolean                                        │
└─────────────────────────────────────────────────────────────────┘
```

### 동작 흐름 (Flow Diagram)

```
1. 사용자 입력
   └─ 전화번호 입력 (010-1234-5678)
      └─ 형식 검증: /^01[0-9]-\d{3,4}-\d{4}$/

2. 인증번호 전송
   └─ "인증번호 전송" 버튼 클릭
      └─ generateVerificationCode() → 6자리 랜덤 숫자
      └─ startPhoneAuthTimer() → 5분 타이머 시작
      └─ verify-area 표시 (인증코드 입력창 노출)

3. 인증번호 입력
   └─ 6자리 코드 입력
      └─ "확인" 버튼 클릭
         ├─ ✅ 일치: validation.phoneVerified = true
         │        모든 UI 비활성화 (재입력 방지)
         │        Next 버튼 활성화
         │
         └─ ❌ 불일치: 에러 메시지 표시
                      재입력 가능

4. 타이머 만료
   └─ 5분 경과
      └─ clearPhoneAuth() → 인증 상태 초기화
      └─ 사용자가 다시 시작 필요
```

---

## 2️⃣ 주요 구현 사항

### A. HTML 구조 (signup.jsp)

#### 전화번호 입력 영역
```html
<label class="field" for="phone">
    <div class="label">전화번호 <span class="small muted">(인증필수)</span></div>
    <div class="input-row">
        <input id="phone" name="phone" class="input" 
               placeholder="010-1234-5678" 
               autocomplete="tel" />
        <button id="send-code" class="btn small outline" type="button">
            인증번호 전송
        </button>
    </div>
    <div id="phone-msg" class="inline-msg" aria-live="polite"></div>
```

#### 인증 영역
```html
<div id="verify-area" class="verify-area" style="display:none">
    <!-- 인증코드 입력 -->
    <input id="verify-code-input" class="input" 
           name="verifyCode" 
           placeholder="인증번호 6자리" />
    
    <!-- 확인 버튼 -->
    <button id="verify-code-btn" class="btn small outline" type="button">
        확인
    </button>
    
    <!-- 타이머 (MM:SS 형식) -->
    <span id="verify-timer" class="timer">5:00</span>
</div>

<!-- 인증 메시지 -->
<div id="verify-msg" class="inline-msg" aria-live="polite"></div>
```

### B. CSS 스타일 (signup-mockup.css)

```css
/* 인증 영역 레이아웃 */
.verify-area {
    display: flex;
    gap: 0.5rem;
    margin-top: 0.75rem;
    align-items: center;
}

.verify-area .input {
    flex: 1;
}

/* 타이머 스타일 */
.timer {
    font-size: 0.9rem;
    color: #ef4444;           /* 빨간색 강조 */
    font-weight: 600;         /* 굵은 폰트 */
    white-space: nowrap;      /* 줄바꿈 방지 */
    min-width: 40px;          /* 최소 너비 */
}

/* 인라인 메시지 */
.inline-msg {
    font-size: 0.85rem;
    margin-top: 0.5rem;
}

.inline-msg.success {
    color: #22c55e;           /* 초록색 */
}

.inline-msg.error {
    color: #ef4444;           /* 빨간색 */
}
```

### C. JavaScript 상태 관리 (signup.js)

#### 전화번호 인증 상태 객체

```javascript
let phoneAuthState = {
    currentPhone: '',              // 현재 입력된 전화번호
    verificationCode: '',          // 생성된 6자리 코드
    timerInterval: null,           // setInterval ID
    timeRemaining: 300,            // 남은 시간 (초)
    isCodeSent: false,             // 코드 생성 여부
    isVerified: false              // 인증 완료 여부
};
```

#### 전화번호 형식 검증

```javascript
function isValidPhone(phone) {
    // 정규표현식: 010-1234-5678 형식만 허용
    const phoneRegex = /^01[0-9]-\d{3,4}-\d{4}$/;
    return phoneRegex.test(phone);
}

// 테스트 예시
isValidPhone('010-1234-5678');  // ✅ true
isValidPhone('01012345678');    // ❌ false
isValidPhone('010-123-456');    // ❌ false
```

#### 인증번호 생성 (Mock)

```javascript
function generateVerificationCode() {
    // 6자리 랜덤 숫자 (100000-999999)
    phoneAuthState.verificationCode = String(
        Math.floor(Math.random() * 900000) + 100000
    );
    
    // 콘솔에 출력 (개발 테스트용)
    console.log('🔐 테스트용 인증번호: ' + phoneAuthState.verificationCode);
}
```

#### 타이머 시작

```javascript
function startPhoneAuthTimer() {
    phoneAuthState.timeRemaining = 300;  // 5분 = 300초
    const timerElement = document.getElementById('verify-timer');
    
    clearInterval(phoneAuthState.timerInterval);
    
    phoneAuthState.timerInterval = setInterval(function() {
        phoneAuthState.timeRemaining--;
        
        // MM:SS 형식으로 표시
        const minutes = Math.floor(phoneAuthState.timeRemaining / 60);
        const seconds = phoneAuthState.timeRemaining % 60;
        const timeStr = minutes + ':' + 
                       (seconds < 10 ? '0' : '') + seconds;
        
        timerElement.textContent = timeStr;
        
        // 시간 만료
        if (phoneAuthState.timeRemaining <= 0) {
            clearInterval(phoneAuthState.timerInterval);
            clearPhoneAuth();
            showMessage(phoneMsg, 
                       '❌ 인증 시간이 만료되었습니다. 다시 인증해주세요.', 
                       'error');
        }
    }, 1000);  // 1초마다 실행
}
```

#### 인증 상태 초기화

```javascript
function clearPhoneAuth() {
    // 상태 초기화
    phoneAuthState.isCodeSent = false;
    phoneAuthState.isVerified = false;
    phoneAuthState.verificationCode = '';
    validation.phoneVerified = false;
    
    // UI 초기화
    verifyArea.style.display = 'none';
    document.getElementById('verify-code-input').value = '';
    document.getElementById('verify-code-input').disabled = false;
    verifyCodeBtn.disabled = false;
    sendCodeBtn.disabled = false;
    phoneInput.disabled = false;
    
    // 타이머 정지
    clearInterval(phoneAuthState.timerInterval);
}
```

---

## 3️⃣ 이벤트 리스너

### 인증번호 전송 버튼

```javascript
sendCodeBtn.addEventListener('click', function() {
    const phone = phoneInput.value.trim();
    
    // 1️⃣ 입력값 검증
    if (!phone) {
        showMessage(phoneMsg, '전화번호를 입력해주세요.', 'error');
        return;
    }

    // 2️⃣ 형식 검증
    if (!isValidPhone(phone)) {
        showMessage(phoneMsg, '올바른 전화번호 형식입니다. (예: 010-1234-5678)', 'error');
        return;
    }

    // 3️⃣ 전화번호 변경 감지
    if (phoneAuthState.currentPhone !== '' && 
        phoneAuthState.currentPhone !== phone) {
        phoneAuthState.isVerified = false;
        phoneAuthState.isCodeSent = false;
        clearPhoneAuth();
        showMessage(phoneMsg, '⚠️ 전화번호가 변경되었습니다. 재인증이 필요합니다.', 'error');
    }

    // 4️⃣ 상태 업데이트
    phoneAuthState.currentPhone = phone;
    generateVerificationCode();
    
    // 5️⃣ UI 표시
    verifyArea.style.display = 'flex';
    sendCodeBtn.disabled = true;
    phoneAuthState.isCodeSent = true;
    
    // 6️⃣ 타이머 시작
    startPhoneAuthTimer();
    showMessage(phoneMsg, '✓ 인증번호가 생성되었습니다.', 'success');
});
```

### 인증 확인 버튼

```javascript
verifyCodeBtn.addEventListener('click', function() {
    const inputCode = document.getElementById('verify-code-input').value.trim();
    
    // 1️⃣ 입력값 검증
    if (!inputCode) {
        showMessage(verifyMsg, '인증번호를 입력해주세요.', 'error');
        return;
    }

    // 2️⃣ 코드 일치 확인
    if (inputCode === phoneAuthState.verificationCode) {
        // ✅ 인증 성공
        showMessage(verifyMsg, '✓ 인증이 완료되었습니다.', 'success');
        validation.phoneVerified = true;
        phoneAuthState.isVerified = true;
        
        // 3️⃣ UI 비활성화 (재입력 방지)
        verifyCodeBtn.disabled = true;
        document.getElementById('verify-code-input').disabled = true;
        phoneInput.disabled = true;
        sendCodeBtn.disabled = true;
        
        // 4️⃣ 타이머 정지
        clearInterval(phoneAuthState.timerInterval);
        
        // 5️⃣ 폼 유효성 재확인
        checkFormValidity();
    } else {
        // ❌ 인증 실패
        showMessage(verifyMsg, '❌ 인증번호가 일치하지 않습니다.', 'error');
        validation.phoneVerified = false;
    }
});
```

### 전화번호 입력 변경 감지

```javascript
phoneInput.addEventListener('input', function() {
    const currentPhone = phoneInput.value.trim();
    
    // 전화번호가 변경되었고, 이미 인증이 완료된 경우
    if (phoneAuthState.currentPhone && 
        currentPhone !== phoneAuthState.currentPhone && 
        phoneAuthState.isVerified) {
        clearPhoneAuth();
        validation.phoneVerified = false;
        checkFormValidity();
    }
});
```

---

## 4️⃣ 테스트 시나리오

### 시나리오 1: 정상 인증 프로세스

```
1. 전화번호 입력: 010-1234-5678
   └─ 유효성 검사 통과

2. "인증번호 전송" 클릭
   └─ 인증번호 생성 (예: 654321)
   └─ 콘솔에 "🔐 테스트용 인증번호: 654321" 출력
   └─ verify-area 표시
   └─ 타이머 시작: 5:00 → 4:59 → ...

3. 인증번호 입력: 654321
   └─ "확인" 버튼 클릭
   └─ ✓ 인증이 완료되었습니다. (메시지)

4. 결과
   └─ validation.phoneVerified = true
   └─ 모든 버튼 비활성화
   └─ "다음" 버튼 활성화
```

### 시나리오 2: 잘못된 형식

```
1. 전화번호 입력: 010-12345 (잘못된 형식)
   └─ "인증번호 전송" 클릭
   └─ ❌ 올바른 전화번호 형식입니다. (예: 010-1234-5678)
```

### 시나리오 3: 타이머 만료

```
1. 전화번호 입력 후 인증번호 전송
2. 5분 대기 (또는 개발자 도구에서 시뮬레이션)
3. 타이머가 0:00에 도달
   └─ clearPhoneAuth() 실행
   └─ verify-area 숨김
   └─ ❌ 인증 시간이 만료되었습니다. 다시 인증해주세요.
```

### 시나리오 4: 전화번호 변경 후 재인증

```
1. 첫 번째 전화번호: 010-1234-5678 → 인증 완료
2. 전화번호 변경: 010-9876-5432
   └─ phoneInput 'input' 이벤트 발생
   └─ clearPhoneAuth() 실행
   └─ ⚠️ 전화번호가 변경되었습니다. 재인증이 필요합니다.
3. 새 전화번호로 다시 인증
```

### 시나리오 5: 잘못된 인증번호

```
1. 인증번호 생성: 654321
2. 잘못된 숫자 입력: 123456
   └─ "확인" 클릭
   └─ ❌ 인증번호가 일치하지 않습니다.
3. 올바른 숫자 입력: 654321
   └─ ✓ 인증이 완료되었습니다.
```

---

## 5️⃣ 브라우저 콘솔 테스트

### 테스트 코드

```javascript
// 1️⃣ 현재 상태 확인
console.log(phoneAuthState);

// 2️⃣ 인증번호 확인
console.log(phoneAuthState.verificationCode);

// 3️⃣ 타이머 상태
console.log(phoneAuthState.timeRemaining + '초 남음');

// 4️⃣ 형식 검증 테스트
console.log(isValidPhone('010-1234-5678'));  // true
console.log(isValidPhone('01012345678'));    // false

// 5️⃣ 인증 상태 변경
phoneAuthState.verificationCode = '123456';
console.log('테스트용 코드로 변경: ' + phoneAuthState.verificationCode);
```

---

## 6️⃣ 배포 후 서버 구현 (선택사항)

### 현재 상태 (로컬 개발)
- ✅ Mock 기반 (클라이언트에서 생성)
- ✅ 타이머 구현 완료
- ✅ 전화번호 형식 검증 완료
- ✅ 재인증 감지 완료

### 프로덕션 구현 시 필요한 항목

1. **서버 엔드포인트**
```
POST /join/send-verification-code
Body: { phoneNumber: "010-1234-5678" }
Response: { code: "success", message: "인증번호 전송됨" }

POST /join/verify-code
Body: { phoneNumber: "010-1234-5678", code: "654321" }
Response: { code: "success", verified: true }
```

2. **세션 저장**
```java
// UserController.java
session.setAttribute("verifiedPhone", "010-1234-5678");
session.setAttribute("phoneVerificationTime", new Date());
```

3. **실제 SMS 발송 (유료 API)**
- NAVER SMS API
- AWS SNS
- Google Cloud Messaging
- Twilio

---

## 7️⃣ 주요 특징

| 기능 | 상태 | 설명 |
|------|------|------|
| **전화번호 형식 검증** | ✅ 완료 | 010-1234-5678 형식만 허용 |
| **인증번호 생성** | ✅ 완료 | 6자리 랜덤 숫자 (Mock) |
| **타이머** | ✅ 완료 | 5분 (300초) 카운트다운 |
| **타이머 만료 처리** | ✅ 완료 | 자동으로 상태 초기화 |
| **전화번호 변경 감지** | ✅ 완료 | 변경 시 재인증 강제 |
| **인증 상태 관리** | ✅ 완료 | phoneAuthState 객체로 추적 |
| **UI 비활성화** | ✅ 완료 | 인증 후 재입력 방지 |
| **폼 유효성 연동** | ✅ 완료 | 다음 버튼과 동기화 |

---

## 8️⃣ 파일 변경 사항

### 수정된 파일

#### 1️⃣ signup.jsp
```diff
- <span id="verify-timer" class="timer"></span>
+ <span id="verify-timer" class="timer">5:00</span>

- <div id="verify-msg" class="inline-msg" style="margin-top:6px"></div>
+ <div id="verify-msg" class="inline-msg" aria-live="polite"></div>
```

#### 2️⃣ signup.js
- ✅ 타이머 시작/정지 함수 추가
- ✅ 전화번호 형식 검증 함수 추가
- ✅ 인증 상태 초기화 함수 추가
- ✅ 전화번호 변경 감지 이벤트 리스너 추가
- ✅ phoneAuthState 객체 생성
- ✅ 인증 필수 조건 추가

---

## 9️⃣ 알려진 제한사항

1. **Mock 인증번호**: 실제 SMS 발송 없음 (테스트 환경용)
2. **로컬 저장**: 세션에 저장되지 않음 (localStorage 사용)
3. **타이머 브라우저 종료**: 탭 닫으면 타이머도 종료됨
4. **보안**: 클라이언트에서 코드 생성 (실제 운영 환경에서는 부적절)

---

## 🔟 다음 단계

### Phase 1 (완료 ✅)
- Mock 기반 클라이언트 인증

### Phase 2 (선택사항)
- 서버 엔드포인트 구현
- 세션 기반 인증 코드 저장
- 데이터베이스 인증 로그 저장

### Phase 3 (선택사항)
- 실제 SMS API 통합 (NAVER/AWS/Twilio)
- 재발송 제한 (최대 3회)
- 인증 실패 로그 기록

---

## 📞 사용 방법

### 개발자로서 테스트하기

1. **브라우저 개발자 도구 열기**: F12
2. **콘솔 탭에서 실행**:
```javascript
// 현재 인증번호 확인
console.log(phoneAuthState.verificationCode);
```
3. **해당 번호를 입력 필드에 입력**
4. **"확인" 버튼 클릭**

### 최종 사용자 관점

1. 전화번호 입력 (010-XXXX-XXXX 형식)
2. "인증번호 전송" 클릭
3. 이메일/문자/앱 알림에서 인증번호 확인 (현재는 콘솔에 출력)
4. 인증번호 입력
5. "확인" 클릭
6. 인증 완료

---

**최종 작성일**: 2024년
**버전**: 1.0
**상태**: 테스트 완료 ✅
