# 🛠️ MySQL 설치 및 데이터베이스 초기화 가이드

## 현재 상황
- ❌ MySQL Server 미설치
- ✅ MySQL Installer만 존재 (C:\Program Files (x86)\MySQL\MySQL Installer for Windows)
- ✅ sanaidump.sql 준비됨 (C:\program\sanaidump.sql)
- ✅ db.properties에 설정 완료 (remote_user / password: 0000)

---

## 📥 MySQL Server 설치 단계

### Step 1: MySQL Installer 실행
```powershell
# Installer 경로
"C:\Program Files (x86)\MySQL\MySQL Installer for Windows"
```

**또는 다음 명령으로 실행**:
```powershell
& "C:\Program Files (x86)\MySQL\MySQL Installer for Windows\MySQLInstaller.exe"
```

### Step 2: 설치 구성
Installer에서 다음 항목 선택:
```
✓ MySQL Server 8.0 (또는 최신)
✓ MySQL Workbench (선택, 관리용)
✓ MySQL Shell (선택)
✓ Connector/J (이미 pom.xml에 포함)
```

### Step 3: 설정
```
포트: 3306 (기본값)
문자셋: UTF-8 (utf8mb4)
Root 비밀번호: 0000 (기본값 사용)
```

### Step 4: Windows 서비스 등록
```
서비스 이름: MySQL80 (또는 MySQL)
시작 유형: 자동
```

---

## ✅ 설치 후 확인

### 1. MySQL 서비스 시작 확인
```powershell
# Services에서 MySQL80 상태 확인
Get-Service MySQL80 | Select-Object Name, Status

# 또는 시작
Start-Service MySQL80

# 상태 확인
Get-Service MySQL80
```

### 2. 포트 확인 (3306이 열려있는지)
```powershell
netstat -an | findstr 3306
# TCP    127.0.0.1:3306    0.0.0.0:0         LISTENING
```

### 3. MySQL 연결 테스트
```powershell
# MySQL Workbench 실행 또는 명령창에서:
$env:Path = "C:\Program Files (x86)\MySQL\MySQL Server 8.0\bin;" + $env:Path
mysql -h localhost -u root -p0000 -e "SELECT VERSION();"
```

예상 출력:
```
+------------------+
| VERSION()        |
+------------------+
| 8.0.33-0 (또는 유사) |
+------------------+
```

---

## 🗄️ 데이터베이스 초기화

### Step 1: sanai 데이터베이스 및 사용자 생성

```sql
-- Root로 접속하여 실행

-- 1. sanai 데이터베이스 생성
CREATE DATABASE IF NOT EXISTS sanai 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- 2. remote_user 계정 생성
CREATE USER IF NOT EXISTS 'remote_user'@'localhost' 
IDENTIFIED BY '0000';

-- 3. 권한 부여
GRANT ALL PRIVILEGES ON sanai.* 
TO 'remote_user'@'localhost';

-- 4. 권한 적용
FLUSH PRIVILEGES;
```

### Step 2: 테이블 및 데이터 생성

```powershell
# 방법 1: 덤프 파일로 import
$env:Path = "C:\Program Files (x86)\MySQL\MySQL Server 8.0\bin;" + $env:Path
mysql -h localhost -u root -p0000 sanai < C:\program\sanaidump.sql
```

```powershell
# 방법 2: SQL 파일이 없는 경우, MySQL에서 직접 테이블 생성
mysql -h localhost -u root -p0000 -e "CREATE TABLE IF NOT EXISTS sanai.users (...);"
```

### Step 3: 데이터베이스 확인

```powershell
# 데이터베이스 목록 확인
mysql -h localhost -u root -p0000 -e "SHOW DATABASES;"

# sanai 테이블 확인
mysql -h localhost -u root -p0000 -e "USE sanai; SHOW TABLES;"

# users 테이블 구조 확인
mysql -h localhost -u root -p0000 -e "USE sanai; DESCRIBE users;"

# 샘플 데이터 확인
mysql -h localhost -u root -p0000 -e "USE sanai; SELECT * FROM users LIMIT 5;"
```

---

## 🔄 Tomcat 연결 테스트

### Step 1: MySQL 서비스 시작
```powershell
Start-Service MySQL80
Start-Sleep -Seconds 2
Get-Service MySQL80  # 상태 확인
```

### Step 2: Tomcat 서버 재시작
```powershell
# 기존 서버 중지
# 또는 CMD 창에서 Ctrl+C

# 새 터미널에서 다시 시작
$env:JAVA_HOME = "C:\program\jdk-11.0.22+7"
$env:CATALINA_HOME = "C:\program\apache-tomcat-9.0.112"
& "$env:CATALINA_HOME\bin\catalina.bat" run
```

### Step 3: 애플리케이션 테스트
```
브라우저에서: http://localhost:9999/ratelocean/
```

로그 확인 (Tomcat 콘솔):
```
✓ Root WebApplicationContext: initialization started
✓ Parsed configuration file: 'mybatis-config.xml'
✓ SqlSessionFactoryBean configured successfully
✓ Root WebApplicationContext initialized in XXX ms
```

---

## 🧪 회원가입 테스트

### 테스트 흐름
```
1. http://localhost:9999/ratelocean/join/select-role.do
   └─ 역할 선택 (프리랜서 선택)

2. http://localhost:9999/ratelocean/join/freelancer
   └─ 기본 정보 입력
   ├─ 로그인 ID: testuser123
   ├─ 이메일: test@example.com
   ├─ 비밀번호: password123!
   ├─ 이름: 테스트
   ├─ 전화번호: 010-1234-5678 (인증 후)
   └─ 계좌 정보 입력

3. POST /join/signup-basic.do
   └─ 데이터베이스에 users 테이블 저장

4. 데이터베이스 확인
   └─ SELECT * FROM users WHERE login_id = 'testuser123';
```

---

## 🚨 문제 해결

### 문제 1: MySQL 서비스가 시작되지 않음
```powershell
# 서비스 상태 확인
Get-Service MySQL80

# 에러 로그 확인 (Event Viewer)
Get-WinEvent -FilterHashtable @{
    LogName = 'System'
    ProviderName = 'Service Control Manager'
} -MaxEvents 10
```

### 문제 2: "Access denied for user 'remote_user'@'localhost'"
```sql
-- Root로 다시 접속하여 암호 재설정
ALTER USER 'remote_user'@'localhost' IDENTIFIED BY '0000';
FLUSH PRIVILEGES;
```

### 문제 3: sanaidump.sql 파일이 없음
```powershell
# 파일 확인
Test-Path "C:\program\sanaidump.sql"

# 있다면 위치 확인
Get-Item "C:\program\sanaidump.sql"
```

### 문제 4: Tomcat이 MySQL 연결 실패
```
로그에 나타나는 메시지:
"Communications link failure"

원인:
1. MySQL 서비스가 실행되지 않음
2. 포트 3306이 다름
3. 사용자 권한 부족

해결:
1. Get-Service MySQL80 확인
2. netstat -an | findstr 3306 확인
3. mysql -u root -p0000 -e "SELECT 1;" 테스트
```

---

## 📊 데이터베이스 스키마 (예상)

```sql
-- users 테이블
CREATE TABLE users (
  user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  login_id VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,  -- 현재 평문, BCrypt 권장
  user_type ENUM('FREELANCER', 'CLIENT') NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(255),
  birth_date DATE,
  profile_image_url VARCHAR(255),
  status ENUM('ACTIVE', 'INACTIVE') DEFAULT 'ACTIVE',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- freelancer_profile 테이블
CREATE TABLE freelancer_profile (
  profile_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  nickname VARCHAR(100),
  introduction TEXT,
  github_url VARCHAR(255),
  website_url VARCHAR(255),
  is_profile_complete BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- account 테이블
CREATE TABLE account (
  account_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  bank_name VARCHAR(100),
  account_number VARCHAR(50),
  account_holder VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);
```

---

## ✨ 최종 확인 체크리스트

- [ ] MySQL Server 8.0 설치됨
- [ ] MySQL 서비스가 자동 시작으로 설정됨
- [ ] sanai 데이터베이스 생성됨
- [ ] remote_user 계정 생성 및 권한 부여됨
- [ ] sanaidump.sql 실행되어 테이블 생성됨
- [ ] MySQL 연결 테스트 성공
- [ ] Tomcat 서버 시작 후 로그 확인 성공
- [ ] http://localhost:9999/ratelocean/ 접속 가능
- [ ] 회원가입 폼 표시됨
- [ ] 회원가입 후 데이터베이스에 저장됨

---

**모든 단계를 완료하면 개발 환경이 100% 준비됩니다!** ✅
