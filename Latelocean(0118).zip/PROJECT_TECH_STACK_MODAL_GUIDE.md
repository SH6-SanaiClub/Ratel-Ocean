# 프로젝트 등록 - 기술스택 모달 통합 가이드

**작성일**: 2026-01-18  
**버전**: 1.0  
**작성자**: GitHub Copilot (Claude Sonnet 4.5)

---

## 📋 목차

1. [개요](#1-개요)
2. [변경 사항 요약](#2-변경-사항-요약)
3. [기술 구조](#3-기술-구조)
4. [구현 세부 사항](#4-구현-세부-사항)
5. [테스트 가이드](#5-테스트-가이드)
6. [DB 구조](#6-db-구조)
7. [트러블슈팅](#7-트러블슈팅)

---

## 1. 개요

### 1.1 목적

프로젝트 등록 페이지의 **Step 2 (기술스택 선택)** 을 프리랜서 회원가입과 동일한 **모달 방식**으로 변경하여 사용자 경험을 통일하고, 각 기술스택마다 **개별 레벨과 경력**을 지정할 수 있도록 개선합니다.

### 1.2 변경 배경

- **기존 방식**: 라디오 버튼(개발 영역) + 체크박스(기술 스택) + 전체 공통 레벨/경력
- **문제점**: 
  - 각 기술스택마다 다른 레벨/경력 지정 불가
  - 프리랜서 회원가입과 UI/UX가 상이함
  - 사용자가 혼란스러움

- **개선 방식**: 
  - 프리랜서 회원가입의 기술스택 모달 사용
  - 각 스택마다 개별 레벨/경력 입력
  - 일관된 사용자 경험 제공

### 1.3 주요 변경점

| 항목 | 기존 방식 | 모달 방식 |
|------|----------|----------|
| 개발 영역 선택 | 라디오 버튼 (1개) | 모달에서 복수 선택 가능 |
| 기술 스택 선택 | 체크박스 (N개) | 모달에서 복수 선택 |
| 레벨/경력 | 전체 공통 적용 | 각 스택마다 개별 지정 |
| UI 컴포넌트 | 일반 폼 | 공통 모달 컴포넌트 |
| 데이터 구조 | `positionId`, `stackIds[]`, `minLevel`, `minYear` | `stackIds[]`, `stackLevels[]`, `stackYears[]` |

---

## 2. 변경 사항 요약

### 2.1 Frontend (JSP/JavaScript)

#### 2.1.1 [create.jsp](src/main/webapp/WEB-INF/views/project/create.jsp)

**변경 내용**:
- Step 2 전체 HTML을 모달 방식으로 교체
- "기술 스택 선택하기 (모달)" 버튼 추가
- 선택된 개발 영역/기술 스택 표시 영역 추가
- Hidden inputs 컨테이너 추가 (`hiddenStackInputs`)
- `tech-stack-modal.jsp` 인클루드 추가
- `tech-stack-modal.js` 로드 추가

**핵심 코드**:
```jsp
<!-- 모달 열기 버튼 -->
<button type="button" class="btn btn-outline" onclick="openProjectTechStackModal()">
    <i class="fa-solid fa-plus-circle"></i>
    기술 스택 선택하기 (모달)
</button>

<!-- 선택된 개발 영역 표시 -->
<div id="selectedAreasDisplay">
    <div id="selectedAreasContainer">
        <!-- JavaScript로 동적 생성 -->
    </div>
</div>

<!-- 선택된 기술 스택 표시 -->
<div id="selectedSkillsDisplay">
    <div id="selectedSkillsContainer">
        <!-- JavaScript로 동적 생성 -->
    </div>
</div>

<!-- Hidden inputs for form submission -->
<div id="hiddenStackInputs"></div>

<!-- 모달 인클루드 -->
<%@ include file="/WEB-INF/views/common/tech-stack-modal.jsp" %>

<!-- JavaScript 로드 -->
<script src="${pageContext.request.contextPath}/resources/js/tech-stack-modal.js"></script>
```

#### 2.1.2 [create.js](src/main/webapp/resources/js/project/create.js)

**변경 내용**:
- 전역 변수 추가: `selectedAreas[]`, `selectedSkills[]`
- `openProjectTechStackModal()` 함수 추가: 모달 열기
- `handleTechStackSelection()` 함수 추가: 모달 콜백 처리
- `renderSelectedAreas()` 함수 추가: 개발 영역 렌더링
- `renderSelectedSkills()` 함수 추가: 기술 스택 렌더링
- `updateAreaLevel()`, `updateAreaYear()` 함수 추가: 개발 영역 레벨/경력 업데이트
- `updateSkillLevel()`, `updateSkillYear()` 함수 추가: 기술 스택 레벨/경력 업데이트
- `removeArea()`, `removeSkill()` 함수 추가: 선택 제거
- `updateHiddenInputs()` 함수 추가: Hidden inputs 생성
- `nextStep()` 함수 수정: Step 2 유효성 검사 변경
- `updatePreview()` 함수 수정: 미리보기 로직 변경

**핵심 코드**:
```javascript
// 전역 변수
let selectedAreas = [];    // { stackId, stackName, stackLevel, stackYear }
let selectedSkills = [];   // { stackId, stackName, stackLevel, stackYear }

// 모달 열기
function openProjectTechStackModal() {
    const preselectedAreas = selectedAreas.map(a => ({ id: a.stackId, name: a.stackName }));
    const preselectedStacks = selectedSkills.map(s => ({ id: s.stackId, name: s.stackName }));
    
    openTechStackModal(handleTechStackSelection, preselectedAreas, preselectedStacks);
}

// 모달 콜백
function handleTechStackSelection(selectedPositions, selectedStacks) {
    selectedAreas = selectedPositions.map(area => ({
        stackId: area.id,
        stackName: area.name,
        stackLevel: null,
        stackYear: null
    }));
    
    selectedSkills = selectedStacks.map(stack => ({
        stackId: stack.id,
        stackName: stack.name,
        stackLevel: null,
        stackYear: null
    }));
    
    renderSelectedAreas();
    renderSelectedSkills();
    updateHiddenInputs();
}

// Hidden Inputs 생성
function updateHiddenInputs() {
    const container = document.getElementById('hiddenStackInputs');
    container.innerHTML = '';
    
    // 개발 영역
    selectedAreas.forEach(area => {
        if (area.stackLevel && area.stackYear !== null) {
            container.innerHTML += `
                <input type="hidden" name="stackIds" value="${area.stackId}">
                <input type="hidden" name="stackLevels" value="${area.stackLevel}">
                <input type="hidden" name="stackYears" value="${area.stackYear}">
            `;
        }
    });
    
    // 기술 스택
    selectedSkills.forEach(skill => {
        if (skill.stackLevel && skill.stackYear !== null) {
            container.innerHTML += `
                <input type="hidden" name="stackIds" value="${skill.stackId}">
                <input type="hidden" name="stackLevels" value="${skill.stackLevel}">
                <input type="hidden" name="stackYears" value="${skill.stackYear}">
            `;
        }
    });
}
```

### 2.2 Backend (Java)

#### 2.2.1 [ProjectCreateRequestDTO.java](src/main/java/com/sanaiclub/domain/project/dto/ProjectCreateRequestDTO.java)

**변경 내용**:
- `positionId`, `minLevel`, `minYear`, `stackIdsUnknown` 필드 제거
- `stackLevels`, `stackYears` 필드 추가

**변경 전**:
```java
private Integer positionId;           // 개발 분야 (1개)
private List<Integer> stackIds;       // 기술 스택 (N개)
private Boolean stackIdsUnknown;      // 기술 스택 미정
private Integer minLevel;             // 공통 레벨
private Integer minYear;              // 공통 경력
```

**변경 후**:
```java
private List<Integer> stackIds;       // 모든 스택 (개발 영역 + 기술 스택)
private List<Integer> stackLevels;    // 각 스택의 레벨
private List<Integer> stackYears;     // 각 스택의 경력
```

#### 2.2.2 [ProjectService.java](src/main/java/com/sanaiclub/domain/project/service/ProjectService.java)

**변경 내용**:
- `createProject()` 메서드 시그니처 변경: `stackIdsUnknown` 파라미터 제거
- Step 4 로직 변경: 각 스택마다 개별 레벨/경력 적용

**변경 전**:
```java
@Transactional
public Integer createProject(ProjectCreateRequestDTO request, Integer clientId, 
                            MultipartFile planFile, Boolean stackIdsUnknown) throws IOException {
    // ...
    
    // 개발분야 (POSITION) 삽입
    if (request.getPositionId() != null) {
        ProjectStackVO positionVO = new ProjectStackVO(
            null, projectId, request.getPositionId(), request.getMinLevel(), request.getMinYear()
        );
        projectMapper.insertProjectStack(positionVO);
    }

    // 기술스택 (SKILL) 삽입
    if (!Boolean.TRUE.equals(stackIdsUnknown) && request.getStackIds() != null) {
        for (Integer stackId : request.getStackIds()) {
            ProjectStackVO skillVO = new ProjectStackVO(
                null, projectId, stackId, request.getMinLevel(), request.getMinYear()
            );
            projectMapper.insertProjectStack(skillVO);
        }
    }
}
```

**변경 후**:
```java
@Transactional
public Integer createProject(ProjectCreateRequestDTO request, Integer clientId, 
                            MultipartFile planFile) throws IOException {
    // ...
    
    // project_stacks 테이블에 삽입 (모달 방식)
    if (request.getStackIds() != null && !request.getStackIds().isEmpty()) {
        List<Integer> stackIds = request.getStackIds();
        List<Integer> stackLevels = request.getStackLevels();
        List<Integer> stackYears = request.getStackYears();
        
        // stackIds, stackLevels, stackYears의 길이가 동일해야 함
        if (stackLevels != null && stackYears != null && 
            stackIds.size() == stackLevels.size() && stackIds.size() == stackYears.size()) {
            
            for (int i = 0; i < stackIds.size(); i++) {
                ProjectStackVO stackVO = new ProjectStackVO(
                    null, 
                    projectId, 
                    stackIds.get(i), 
                    stackLevels.get(i), 
                    stackYears.get(i)
                );
                projectMapper.insertProjectStack(stackVO);
            }
        } else {
            System.err.println("⚠️ stackIds, stackLevels, stackYears 길이 불일치!");
        }
    }
}
```

#### 2.2.3 [ProjectController.java](src/main/java/com/sanaiclub/domain/project/controller/ProjectController.java)

**변경 내용**:
- `createProcess()` 메서드 시그니처 변경: `stackIdsUnknown` 파라미터 제거
- 주석 업데이트: 모달 방식 설명 추가

**변경 전**:
```java
@PostMapping("/project/create")
public String createProcess(@ModelAttribute ProjectCreateRequestDTO request,
                           @RequestParam("planFile") MultipartFile planFile,
                           @RequestParam(value = "stackIdsUnknown", required = false) Boolean stackIdsUnknown,
                           HttpSession session) {
    // ...
    projectId = projectService.createProject(request, clientId, planFile, stackIdsUnknown);
}
```

**변경 후**:
```java
@PostMapping("/project/create")
public String createProcess(@ModelAttribute ProjectCreateRequestDTO request,
                           @RequestParam("planFile") MultipartFile planFile,
                           HttpSession session) {
    // ...
    projectId = projectService.createProject(request, clientId, planFile);
}
```

---

## 3. 기술 구조

### 3.1 아키텍처 다이어그램

```
┌──────────────────────────────────────────────────────────────┐
│                      Frontend Layer                          │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  create.jsp                                                  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  Step 2: 기술 스택 선택                                │  │
│  │                                                         │  │
│  │  [기술 스택 선택하기 (모달)] ← 버튼 클릭                │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────┐      │  │
│  │  │ 선택된 개발 영역 (selectedAreasDisplay)      │      │  │
│  │  │  - 웹 (Lv.3, 2년)        [삭제]              │      │  │
│  │  │  - 모바일앱 (Lv.4, 3년)  [삭제]              │      │  │
│  │  └─────────────────────────────────────────────┘      │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────┐      │  │
│  │  │ 선택된 기술 스택 (selectedSkillsDisplay)     │      │  │
│  │  │  - React (Lv.3, 2년)      [삭제]             │      │  │
│  │  │  - Java (Lv.4, 4년)       [삭제]             │      │  │
│  │  └─────────────────────────────────────────────┘      │  │
│  │                                                         │  │
│  │  <input type="hidden" name="stackIds" value="1">      │  │
│  │  <input type="hidden" name="stackLevels" value="3">   │  │
│  │  <input type="hidden" name="stackYears" value="2">    │  │
│  │  ...                                                   │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  tech-stack-modal.jsp (공통 컴포넌트)                        │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  [기술 스택 선택 모달]                                 │  │
│  │                                                         │  │
│  │  개발 영역: [웹] [모바일앱] [AI/ML] ...                │  │
│  │  기술 스택: [React] [Java] [Python] ...                │  │
│  │                                                         │  │
│  │  [취소] [선택 완료]                                    │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  create.js + tech-stack-modal.js                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  openProjectTechStackModal()                           │  │
│  │    ↓                                                   │  │
│  │  openTechStackModal(callback)                          │  │
│  │    ↓                                                   │  │
│  │  사용자 선택 (개발 영역 + 기술 스택)                   │  │
│  │    ↓                                                   │  │
│  │  callback(selectedAreas, selectedSkills)               │  │
│  │    ↓                                                   │  │
│  │  handleTechStackSelection()                            │  │
│  │    ├─ renderSelectedAreas()                            │  │
│  │    ├─ renderSelectedSkills()                           │  │
│  │    └─ updateHiddenInputs()                             │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
                             ↓
                    [폼 제출 (POST)]
                             ↓
┌──────────────────────────────────────────────────────────────┐
│                      Backend Layer                           │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ProjectController.java                                      │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  @PostMapping("/project/create")                       │  │
│  │  createProcess(DTO, file, session)                     │  │
│  │    ↓                                                   │  │
│  │  세션 인증 (CLIENT 확인)                               │  │
│  │    ↓                                                   │  │
│  │  projectService.createProject()                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  ProjectService.java                                         │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  @Transactional                                        │  │
│  │  createProject(DTO, clientId, file)                    │  │
│  │    ↓                                                   │  │
│  │  1. ProjectVO 생성 및 매핑                             │  │
│  │  2. 기획서 파일 업로드 (선택)                          │  │
│  │  3. projects 테이블 삽입                               │  │
│  │  4. project_stacks 테이블 삽입 (루프)                 │  │
│  │     for (i = 0; i < stackIds.size(); i++) {           │  │
│  │       ProjectStackVO(projectId, stackIds[i],          │  │
│  │                     stackLevels[i], stackYears[i])    │  │
│  │       insertProjectStack()                            │  │
│  │     }                                                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
                             ↓
┌──────────────────────────────────────────────────────────────┐
│                      Database Layer                          │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  projects 테이블                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  project_id | client_id | title | budget | ...        │  │
│  │  ────────────────────────────────────────────────────│  │
│  │      1      |     10    | "웹앱" | 5000000 | ...      │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  project_stacks 테이블 (다대다 관계)                         │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  project_id | stack_id | stack_level | stack_year     │  │
│  │  ──────────────────────────────────────────────────  │  │
│  │      1      |    1     |      3      |      2         │  │
│  │      1      |    5     |      4      |      3         │  │
│  │      1      |   15     |      3      |      2         │  │
│  │      1      |   20     |      4      |      4         │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
│  stacks 테이블 (기준 데이터)                                 │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  stack_id | stack_name | category                     │  │
│  │  ──────────────────────────────────────────────────  │  │
│  │      1    |    "웹"    | POSITION                     │  │
│  │      5    | "모바일앱"  | POSITION                     │  │
│  │     15    |  "React"   | SKILL                        │  │
│  │     20    |  "Java"    | SKILL                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 3.2 데이터 흐름

```
[사용자] → [모달 열기] → [개발 영역 선택] → [기술 스택 선택] → [레벨/경력 입력] → [선택 완료]
                                                                              ↓
                                                                    [콜백 함수 호출]
                                                                              ↓
                                                                    [JavaScript 배열 저장]
                                                                    selectedAreas[]
                                                                    selectedSkills[]
                                                                              ↓
                                                                    [HTML 렌더링]
                                                                    - 카드 형태 표시
                                                                    - 레벨/경력 드롭다운
                                                                              ↓
                                                                    [Hidden Inputs 생성]
                                                                    stackIds[]
                                                                    stackLevels[]
                                                                    stackYears[]
                                                                              ↓
                                                                    [폼 제출 (POST)]
                                                                              ↓
[Controller] ← [DTO 바인딩] ← [Spring MVC] ← [HTTP Request]
      ↓
[Service] → [Transactional] → [DB 삽입]
                              projects (1건)
                              project_stacks (N건)
```

---

## 4. 구현 세부 사항

### 4.1 Frontend 상세 구현

#### 4.1.1 모달 콜백 함수

```javascript
function handleTechStackSelection(selectedPositions, selectedStacks) {
    console.log('✅ 선택된 개발 영역:', selectedPositions);
    console.log('✅ 선택된 기술 스택:', selectedStacks);
    
    // 개발 영역 처리 (레벨과 경력은 사용자가 직접 입력)
    selectedAreas = selectedPositions.map(area => ({
        stackId: area.id,
        stackName: area.name,
        stackLevel: null,   // 사용자가 직접 입력
        stackYear: null     // 사용자가 직접 입력
    }));
    
    // 기술 스택 처리 (레벨과 경력은 사용자가 직접 입력)
    selectedSkills = selectedStacks.map(stack => ({
        stackId: stack.id,
        stackName: stack.name,
        stackLevel: null,   // 사용자가 직접 입력
        stackYear: null     // 사용자가 직접 입력
    }));
    
    renderSelectedAreas();
    renderSelectedSkills();
    updateHiddenInputs();
}
```

#### 4.1.2 카드 형태 렌더링

```javascript
function renderSelectedAreas() {
    const container = document.getElementById('selectedAreasContainer');
    const display = document.getElementById('selectedAreasDisplay');
    
    if (selectedAreas.length === 0) {
        display.style.display = 'none';
        return;
    }
    
    display.style.display = 'block';
    container.innerHTML = '';
    
    selectedAreas.forEach((area, index) => {
        const card = document.createElement('div');
        card.style.cssText = 'flex: 1; min-width: 250px; padding: 1.5rem; border: 2px solid #94D9DB; border-radius: 10px; background: #f8f9fa;';
        card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <strong style="font-size: 1.1rem; color: #1F7A8C;">${area.stackName}</strong>
                <button type="button" onclick="removeArea(${index})" 
                        style="background: none; border: none; color: #d32f2f; font-size: 1.5rem; cursor: pointer;">&times;</button>
            </div>
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.9rem; color: #666; margin-bottom: 0.3rem;">요구 숙련도</label>
                <select onchange="updateAreaLevel(${index}, this.value)" class="form-control">
                    <option value="">선택</option>
                    <option value="1" ${area.stackLevel == 1 ? 'selected' : ''}>Lv.1 입문</option>
                    <option value="2" ${area.stackLevel == 2 ? 'selected' : ''}>Lv.2 초급</option>
                    <option value="3" ${area.stackLevel == 3 ? 'selected' : ''}>Lv.3 중급</option>
                    <option value="4" ${area.stackLevel == 4 ? 'selected' : ''}>Lv.4 중급+</option>
                    <option value="5" ${area.stackLevel == 5 ? 'selected' : ''}>Lv.5 고급</option>
                </select>
            </div>
            <div>
                <label style="display: block; font-size: 0.9rem; color: #666; margin-bottom: 0.3rem;">필요 경력 (년)</label>
                <input type="number" onchange="updateAreaYear(${index}, this.value)" 
                       value="${area.stackYear || ''}" min="0" placeholder="0" class="form-control">
            </div>
        `;
        container.appendChild(card);
    });
}
```

#### 4.1.3 유효성 검사

```javascript
// Step 2: 기술 스택 필수 검사 (개발 영역 + 기술 스택 중 최소 1개)
if (currentStep === 2) {
    if (selectedAreas.length === 0 && selectedSkills.length === 0) {
        alert("개발 영역 또는 기술 스택을 최소 1개 이상 선택해주세요.");
        isValid = false;
    } else {
        // 선택된 영역/스택의 레벨과 경력이 모두 입력되었는지 확인
        let allComplete = true;
        
        for (let area of selectedAreas) {
            if (!area.stackLevel || area.stackYear === null || area.stackYear === undefined) {
                allComplete = false;
                break;
            }
        }
        
        for (let skill of selectedSkills) {
            if (!skill.stackLevel || skill.stackYear === null || skill.stackYear === undefined) {
                allComplete = false;
                break;
            }
        }
        
        if (!allComplete) {
            alert("선택된 모든 기술 스택의 레벨과 경력을 입력해주세요.");
            isValid = false;
        }
    }
}
```

### 4.2 Backend 상세 구현

#### 4.2.1 DTO 바인딩

**Spring MVC가 자동으로 처리**:
```
POST /project/create
Content-Type: multipart/form-data

stackIds=1&stackLevels=3&stackYears=2&
stackIds=5&stackLevels=4&stackYears=3&
stackIds=15&stackLevels=3&stackYears=2&
stackIds=20&stackLevels=4&stackYears=4
```

**→ ProjectCreateRequestDTO 매핑**:
```java
stackIds    = [1, 5, 15, 20]
stackLevels = [3, 4, 3, 4]
stackYears  = [2, 3, 2, 4]
```

#### 4.2.2 DB 삽입 로직

```java
if (request.getStackIds() != null && !request.getStackIds().isEmpty()) {
    List<Integer> stackIds = request.getStackIds();
    List<Integer> stackLevels = request.getStackLevels();
    List<Integer> stackYears = request.getStackYears();
    
    // 데이터 유효성 검사
    if (stackLevels != null && stackYears != null && 
        stackIds.size() == stackLevels.size() && stackIds.size() == stackYears.size()) {
        
        // 각 스택마다 개별 레벨/경력으로 삽입
        for (int i = 0; i < stackIds.size(); i++) {
            ProjectStackVO stackVO = new ProjectStackVO(
                null,                   // project_stack_id (AUTO_INCREMENT)
                projectId,              // project_id (FK)
                stackIds.get(i),        // stack_id (FK)
                stackLevels.get(i),     // stack_level (1~5)
                stackYears.get(i)       // stack_year (년)
            );
            projectMapper.insertProjectStack(stackVO);
        }
    } else {
        // 데이터 불일치 시 에러 로깅
        System.err.println("⚠️ stackIds, stackLevels, stackYears 길이 불일치!");
    }
}
```

---

## 5. 테스트 가이드

### 5.1 환경 준비

1. **Tomcat 서버 시작**
   - 경로: `C:\program\apache-tomcat-9.0.112\bin\startup.bat`
   - 포트: 9999
   - URL: http://localhost:9999/ratelocean

2. **로그인**
   - 클라이언트 계정으로 로그인
   - `userType = "CLIENT"` 확인

### 5.2 테스트 시나리오

#### 5.2.1 정상 플로우

```
Step 1: 프로젝트 등록 페이지 접근
  → http://localhost:9999/ratelocean/project/create
  → Step 1 (프로젝트 개요) 화면 확인

Step 2: 프로젝트 기본 정보 입력
  → 제목: "반응형 웹사이트 개발"
  → 설명: "React와 Spring Boot를 활용한 풀스택 개발"
  → [다음 단계] 클릭

Step 3: 기술 스택 선택 (모달)
  → [기술 스택 선택하기 (모달)] 버튼 클릭
  → 모달이 열림
  
Step 4: 개발 영역 선택
  → "웹" 클릭
  → "모바일앱" 클릭
  → 2개 선택 확인

Step 5: 기술 스택 선택
  → "React" 클릭
  → "Java" 클릭
  → "Spring Boot" 클릭
  → 3개 선택 확인
  
Step 6: 선택 완료
  → [선택 완료] 버튼 클릭
  → 모달 닫힘

Step 7: 레벨/경력 입력
  → 개발 영역 카드 확인
    - 웹: Lv.3 중급, 2년
    - 모바일앱: Lv.4 중급+, 3년
  → 기술 스택 카드 확인
    - React: Lv.3 중급, 2년
    - Java: Lv.4 중급+, 4년
    - Spring Boot: Lv.3 중급, 2년
  → [다음 단계] 클릭

Step 8: 예산 및 일정 입력
  → 예산: 5,000,000원
  → 시작일: "즉시 시작"
  → 진행 기간: "1~3개월"
  → [다음 단계] 클릭

Step 9: 계약 및 소통
  → 미팅 방식: "온라인 미팅"
  → 대금 지급: "일괄 지급"
  → 수정 횟수: 2회
  → [미리보기] 클릭

Step 10: 미리보기 확인
  → 카테고리: "웹, 모바일앱"
  → 기술 스택: "웹 (Lv.3, 2년), 모바일앱 (Lv.4, 3년), React (Lv.3, 2년), Java (Lv.4, 4년), Spring Boot (Lv.3, 2년)"
  → [등록 완료] 클릭

Step 11: 등록 성공
  → success 페이지로 리다이렉트
  → "프로젝트가 성공적으로 등록되었습니다!" 메시지 확인
```

#### 5.2.2 유효성 검사

**테스트 1: 기술 스택 미선택**
```
- Step 2에서 모달 열지 않고 [다음 단계] 클릭
- 예상 결과: "개발 영역 또는 기술 스택을 최소 1개 이상 선택해주세요." 알림
```

**테스트 2: 레벨 미입력**
```
- 모달에서 "웹" 선택 → 완료
- 레벨 드롭다운을 "선택"으로 유지
- [다음 단계] 클릭
- 예상 결과: "선택된 모든 기술 스택의 레벨과 경력을 입력해주세요." 알림
```

**테스트 3: 경력 미입력**
```
- 모달에서 "React" 선택 → 완료
- 레벨: Lv.3 선택, 경력: 공백
- [다음 단계] 클릭
- 예상 결과: "선택된 모든 기술 스택의 레벨과 경력을 입력해주세요." 알림
```

#### 5.2.3 데이터 검증

**DB 확인**:
```sql
-- 프로젝트 확인
SELECT * FROM projects WHERE project_id = 1;

-- 프로젝트-스택 매핑 확인
SELECT 
    ps.project_stack_id,
    ps.project_id,
    s.stack_name,
    s.category,
    ps.stack_level,
    ps.stack_year
FROM project_stacks ps
JOIN stacks s ON ps.stack_id = s.stack_id
WHERE ps.project_id = 1
ORDER BY s.category, s.stack_name;
```

**예상 결과**:
```
project_stack_id | project_id | stack_name   | category | stack_level | stack_year
-----------------|------------|--------------|----------|-------------|------------
       1         |     1      | 모바일앱      | POSITION |      4      |     3
       2         |     1      | 웹           | POSITION |      3      |     2
       3         |     1      | Java         | SKILL    |      4      |     4
       4         |     1      | React        | SKILL    |      3      |     2
       5         |     1      | Spring Boot  | SKILL    |      3      |     2
```

### 5.3 브라우저 콘솔 확인

**정상 동작 시 콘솔 로그**:
```
🚀 프로젝트 기술 스택 모달 열기
✅ 선택된 개발 영역: [{id: 1, name: "웹"}, {id: 5, name: "모바일앱"}]
✅ 선택된 기술 스택: [{id: 15, name: "React"}, {id: 20, name: "Java"}, {id: 25, name: "Spring Boot"}]
📦 선택된 개발 영역: [{stackId: 1, stackName: "웹", stackLevel: null, stackYear: null}, ...]
📦 선택된 기술 스택: [{stackId: 15, stackName: "React", stackLevel: null, stackYear: null}, ...]
```

---

## 6. DB 구조

### 6.1 테이블 스키마

#### 6.1.1 projects 테이블

```sql
CREATE TABLE projects (
    project_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    budget INT,
    budget_negotiable TINYINT(1) DEFAULT 0,
    est_duration VARCHAR(50),
    duration_negotiable TINYINT(1) DEFAULT 0,
    start_date DATE,
    deadline_date DATE,
    communicate_method VARCHAR(20),
    payment_method VARCHAR(20),
    max_revision_count INT,
    change_policy TEXT,
    project_status VARCHAR(20),
    is_public TINYINT(1) DEFAULT 1,
    plan_url VARCHAR(500),
    file_size VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(client_id)
);
```

#### 6.1.2 project_stacks 테이블

```sql
CREATE TABLE project_stacks (
    project_stack_id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    stack_id INT NOT NULL,
    stack_level INT NOT NULL COMMENT '요구 숙련도 (1~5)',
    stack_year INT NOT NULL COMMENT '요구 경력 (년)',
    FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    FOREIGN KEY (stack_id) REFERENCES stacks(stack_id)
);
```

#### 6.1.3 stacks 테이블

```sql
CREATE TABLE stacks (
    stack_id INT PRIMARY KEY AUTO_INCREMENT,
    stack_name VARCHAR(100) NOT NULL,
    category VARCHAR(20) NOT NULL COMMENT 'POSITION 또는 SKILL',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 6.2 데이터 예시

#### stacks 테이블 샘플 데이터

```sql
INSERT INTO stacks (stack_id, stack_name, category) VALUES
(1, '웹', 'POSITION'),
(2, '게임/그래픽', 'POSITION'),
(3, '데이터베이스', 'POSITION'),
(4, 'AI/ML', 'POSITION'),
(5, '모바일앱', 'POSITION'),
(6, 'DevOps/인프라', 'POSITION'),
(7, '임베디드/하드웨어', 'POSITION'),
(15, 'React', 'SKILL'),
(16, 'Vue.js', 'SKILL'),
(17, 'Angular', 'SKILL'),
(20, 'Java', 'SKILL'),
(21, 'Python', 'SKILL'),
(22, 'JavaScript', 'SKILL'),
(25, 'Spring Boot', 'SKILL'),
(26, 'Django', 'SKILL'),
(27, 'Node.js', 'SKILL');
```

### 6.3 ER 다이어그램

```
┌─────────────────────┐         ┌─────────────────────┐
│     clients         │         │      stacks         │
├─────────────────────┤         ├─────────────────────┤
│ client_id (PK)      │         │ stack_id (PK)       │
│ email               │         │ stack_name          │
│ company_name        │         │ category            │
│ ...                 │         │ created_at          │
└─────────────────────┘         └─────────────────────┘
         │                                  │
         │ 1                                │ N
         │                                  │
         ↓                                  ↓
┌─────────────────────┐         ┌─────────────────────┐
│     projects        │ 1     N │  project_stacks     │
├─────────────────────┤◄────────┤─────────────────────┤
│ project_id (PK)     │         │ project_stack_id(PK)│
│ client_id (FK)      │         │ project_id (FK)     │
│ title               │         │ stack_id (FK)       │
│ description         │         │ stack_level         │
│ budget              │         │ stack_year          │
│ start_date          │         └─────────────────────┘
│ deadline_date       │                  ↑
│ project_status      │                  │ N
│ ...                 │                  │
└─────────────────────┘                  │
                                         1
```

---

## 7. 트러블슈팅

### 7.1 모달이 열리지 않음

**증상**:
- "기술 스택 선택하기 (모달)" 버튼 클릭 시 아무 반응 없음

**원인**:
- `tech-stack-modal.js` 로드 실패
- `openTechStackModal` 함수 미정의

**해결 방법**:
1. 브라우저 콘솔 확인:
   ```javascript
   typeof openTechStackModal
   // "function"이 나와야 함
   ```

2. JSP 파일 확인:
   ```jsp
   <script src="${pageContext.request.contextPath}/resources/js/tech-stack-modal.js"></script>
   ```

3. 파일 존재 확인:
   ```
   src/main/webapp/resources/js/tech-stack-modal.js
   ```

### 7.2 Hidden Inputs 생성 안 됨

**증상**:
- 폼 제출 시 `stackIds`, `stackLevels`, `stackYears`가 null

**원인**:
- `updateHiddenInputs()` 함수 미호출
- 레벨/경력 미입력

**해결 방법**:
1. 콘솔 로그 확인:
   ```javascript
   console.log('selectedAreas:', selectedAreas);
   console.log('selectedSkills:', selectedSkills);
   ```

2. Hidden inputs 확인:
   ```javascript
   document.getElementById('hiddenStackInputs').innerHTML
   ```

3. 조건 검사:
   ```javascript
   // stackLevel과 stackYear가 모두 입력되어야 hidden input 생성
   if (area.stackLevel && area.stackYear !== null) { ... }
   ```

### 7.3 DB 삽입 실패

**증상**:
- `projectId`는 생성되었으나 `project_stacks` 테이블에 데이터 없음

**원인**:
- DTO 리스트 길이 불일치
- 트랜잭션 롤백

**해결 방법**:
1. 로그 확인:
   ```
   ⚠️ stackIds, stackLevels, stackYears 길이 불일치!
   ```

2. 콘솔 로그 추가 (ProjectService.java):
   ```java
   System.out.println("stackIds size: " + stackIds.size());
   System.out.println("stackLevels size: " + stackLevels.size());
   System.out.println("stackYears size: " + stackYears.size());
   ```

3. Frontend 검증 강화:
   ```javascript
   // updateHiddenInputs()에서 모든 스택의 레벨/경력 확인
   ```

### 7.4 미리보기 표시 오류

**증상**:
- Step 5 (미리보기)에서 기술 스택이 "미선택"으로 표시됨

**원인**:
- `updatePreview()` 함수가 `selectedAreas`, `selectedSkills` 접근 못 함

**해결 방법**:
1. 콘솔 로그 확인:
   ```javascript
   console.log('updatePreview 호출');
   console.log('selectedAreas:', selectedAreas);
   console.log('selectedSkills:', selectedSkills);
   ```

2. 전역 변수 확인:
   ```javascript
   // create.js 최상단에 선언되어 있는지 확인
   let selectedAreas = [];
   let selectedSkills = [];
   ```

### 7.5 세션 인증 오류

**증상**:
- 프로젝트 등록 시 로그인 페이지로 리다이렉트

**원인**:
- 세션에 `userId` 또는 `userType` 없음

**해결 방법**:
1. 로그인 시 세션 설정 확인:
   ```java
   session.setAttribute("userId", clientId);
   session.setAttribute("userType", "CLIENT");
   ```

2. 세션 확인 (JSP):
   ```jsp
   <c:if test="${empty userId}">
       <script>alert('로그인이 필요합니다.'); location.href='/login';</script>
   </c:if>
   ```

---

## 8. 향후 개선 사항

### 8.1 단기 개선 (1주일)

1. **파일 업로드 개선**
   - 다중 파일 업로드 지원
   - 드래그 앤 드롭 UI

2. **유효성 검사 강화**
   - 예산 범위 검증 (최소/최대)
   - 기간 논리 검증 (시작일 < 마감일)

3. **에러 처리 개선**
   - 사용자 친화적 에러 메시지
   - 에러 발생 시 입력값 복원

### 8.2 중기 개선 (1개월)

1. **기술 스택 추천**
   - AI 기반 프로젝트 내용 분석
   - 적합한 기술 스택 자동 추천

2. **템플릿 기능**
   - 자주 사용하는 프로젝트 형태를 템플릿으로 저장
   - 템플릿 불러오기

3. **실시간 예산 계산기**
   - 기술 스택, 레벨, 경력 기반 예상 비용 산출

### 8.3 장기 개선 (3개월)

1. **프로젝트 분석 대시보드**
   - 기술 스택별 프로젝트 통계
   - 시장 트렌드 분석

2. **프리랜서 매칭 알고리즘**
   - 프로젝트 요구사항과 프리랜서 프로필 자동 매칭
   - 매칭 점수 및 추천 이유 제공

3. **프로젝트 관리 도구**
   - 마일스톤 관리
   - 진행률 추적
   - 결제 관리

---

## 9. 참고 자료

### 9.1 관련 파일

- **Frontend**
  - [create.jsp](src/main/webapp/WEB-INF/views/project/create.jsp)
  - [create.js](src/main/webapp/resources/js/project/create.js)
  - [tech-stack-modal.jsp](src/main/webapp/WEB-INF/views/common/tech-stack-modal.jsp)
  - [tech-stack-modal.js](src/main/webapp/resources/js/tech-stack-modal.js)

- **Backend**
  - [ProjectController.java](src/main/java/com/sanaiclub/domain/project/controller/ProjectController.java)
  - [ProjectService.java](src/main/java/com/sanaiclub/domain/project/service/ProjectService.java)
  - [ProjectCreateRequestDTO.java](src/main/java/com/sanaiclub/domain/project/dto/ProjectCreateRequestDTO.java)
  - [ProjectVO.java](src/main/java/com/sanaiclub/domain/project/vo/ProjectVO.java)
  - [ProjectStackVO.java](src/main/java/com/sanaiclub/domain/project/vo/ProjectStackVO.java)

- **MyBatis**
  - [ProjectMapper.xml](src/main/resources/mybatis/mappers/project/ProjectMapper.xml)
  - [StackMapper.xml](src/main/resources/mybatis/mappers/project/StackMapper.xml)

### 9.2 이전 문서

- [PROJECT_REGISTRATION_COMPLETE.md](PROJECT_REGISTRATION_COMPLETE.md) - 초기 프로젝트 등록 구현 문서
- [FREELANCER_PROFILE_MODAL_GUIDE.md](FREELANCER_PROFILE_MODAL_GUIDE.md) - 프리랜서 프로필 모달 가이드

### 9.3 외부 라이브러리

- **Spring Framework**: 5.3.39
- **MyBatis**: 3.5.16
- **jQuery**: 3.6.0 (모달 컴포넌트에서 사용)
- **Font Awesome**: 6.x (아이콘)

---

## 10. 변경 이력

| 버전 | 날짜 | 작성자 | 변경 내용 |
|------|------|--------|-----------|
| 1.0 | 2026-01-18 | GitHub Copilot | 최초 작성: 기술스택 모달 통합 완료 |

---

**문서 끝**
