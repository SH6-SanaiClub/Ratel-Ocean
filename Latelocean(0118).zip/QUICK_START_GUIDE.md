# ⚡ 빠른 시작 가이드 (Quick Start)

## 🎯 목표

이 문서는 구현된 회원가입 및 프로필 완성 시스템을 **2분 안에 테스트**하는 방법을 설명합니다.

---

## 1️⃣ 전화번호 인증 테스트 (1분)

### 준비물
- 브라우저 (Chrome, Firefox, Safari 등)
- 개발자 도구 (F12)

### 단계별 실행

#### Step 1: 회원가입 페이지 열기
```
URL: http://localhost:8080/ratelocean/join/signup.do
또는
http://your-domain/join/signup.do
```

#### Step 2: 전화번호 입력
```
전화번호 필드에 입력: 010-1234-5678
(형식: 010-XXXX-XXXX)
```

#### Step 3: 인증번호 전송
```
클릭: "인증번호 전송" 버튼
결과: 
  ✓ 인증번호가 생성되었습니다. (메시지)
  - 인증번호 입력 필드 표시
  - 타이머 시작: 5:00 → 4:59 → ...
```

#### Step 4: 콘솔에서 인증번호 확인
```
F12 → Console 탭 → 다음 코드 실행:
console.log(phoneAuthState.verificationCode);

결과: 654321 (예시)
```

#### Step 5: 인증번호 확인
```
인증번호 입력: 위에서 확인한 숫자 입력 (예: 654321)
클릭: "확인" 버튼
결과: ✓ 인증이 완료되었습니다.
```

#### Step 6: "다음" 버튼 활성화 확인
```
다른 필수 필드를 모두 입력하면
"다음" 버튼이 활성화됨
```

---

## 2️⃣ 기술 스택 모달 테스트 (1분)

### 준비물
- 프리랜서 역할 선택 후 프로필 페이지

### 단계별 실행

#### Step 1: 프로필 완성 페이지 열기
```
URL: http://localhost:8080/ratelocean/freelancer/complete-profile.do
또는
http://your-domain/freelancer/complete-profile.do
```

#### Step 2: 기술 스택 버튼 클릭
```
클릭: "🔍 기술 스택 선택 (모달)" 버튼

결과:
  - 모달 창이 열림
  - 검색 창과 기술 목록 표시
```

#### Step 3: 기술 선택 (3개 이상)
```
선택 예시:
  ☑ Java
  ☑ React
  ☑ AWS
  ☑ MySQL

(더 많이 선택 가능)
```

#### Step 4: 모달 "확인" 클릭
```
클릭: "확인" 버튼

결과:
  - 선택된 기술이 태그로 표시됨
  - 각 기술 아래 숙련도/경력 입력 폼 표시
```

#### Step 5: 숙련도 및 경력 입력
```
각 기술별로:
  Lv.: 1~5 선택 (1=초급, 5=전문가)
  경력: 0.5~10년 입력 (0.5년 단위)
```

#### Step 6: 모달 다시 열기
```
클릭: "🔍 기술 스택 선택 (모달)" 다시 클릭

결과:
  - 기존 선택항목이 체크된 상태로 표시
  - 추가/제거 가능
```

---

## 🔍 개발자 도구 활용

### Console 명령어

#### 1. 전화번호 인증 상태 확인
```javascript
// 현재 인증번호
console.log(phoneAuthState.verificationCode);

// 남은 시간
console.log(phoneAuthState.timeRemaining + '초');

// 전체 상태
console.log(phoneAuthState);

// 인증 완료 여부
console.log(validation.phoneVerified);
```

#### 2. 기술 스택 상태 확인
```javascript
// 선택된 기술 목록
console.log(selectedSkills);

// 기술 개수
console.log(selectedSkills.length);

// 첫 번째 기술 상세
console.log(selectedSkills[0]);
```

#### 3. 폼 유효성 검사
```javascript
// 전화번호 형식 검증
console.log(isValidPhone('010-1234-5678'));  // true
console.log(isValidPhone('01012345678'));    // false

// 폼 유효성
console.log(validateForm());
```

---

## ✅ 테스트 체크리스트 (2분)

### 전화번호 인증
- [ ] 올바른 형식 입력 시 진행 가능
- [ ] 잘못된 형식 입력 시 에러 표시
- [ ] 인증번호 전송 후 타이머 시작
- [ ] 올바른 코드 입력 시 인증 완료
- [ ] 잘못된 코드 입력 시 에러 메시지
- [ ] 인증 후 필드 비활성화 (재입력 방지)

### 기술 스택 모달
- [ ] 모달 열기/닫기 작동
- [ ] 기술 선택/체크 작동
- [ ] "확인" 버튼으로 선택값 저장
- [ ] 태그 형식으로 표시
- [ ] 숙련도/경력 수정 가능
- [ ] 기술 삭제 가능
- [ ] 모달 재열기 시 기존 선택값 유지

### 폼 제출
- [ ] 기술 미선택 시 제출 불가
- [ ] 기술 1개 이상 시 제출 가능
- [ ] 필수 필드 미입력 시 경고
- [ ] 모든 필드 입력 후 제출 가능

---

## 🐛 문제 해결 (Troubleshooting)

### 문제: 전화번호 형식 검증 실패
```
증상: "올바른 전화번호 형식입니다" 메시지
해결: 010-1234-5678 형식으로 입력 (하이픈 필수)

❌ 잘못된 형식:
  - 01012345678 (하이픈 없음)
  - 010-123-456 (숫자 개수 부족)
  - 01-2345-6789 (잘못된 포맷)

✅ 올바른 형식:
  - 010-1234-5678
  - 010-9876-5432
  - 011-1234-5678
```

### 문제: 인증번호 콘솔에 안 보임
```
해결 방법:
1. F12 → Console 탭 클릭
2. 필터 레벨을 "All"로 설정
3. 다시 "인증번호 전송" 클릭
4. 콘솔에 "🔐 테스트용 인증번호: xxxxxx" 확인

또는 다음 명령어 실행:
console.log(phoneAuthState.verificationCode);
```

### 문제: 모달이 열리지 않음
```
확인 사항:
1. tech-stack-modal.jsp 파일이 존재하는지 확인
2. tech-stack-modal.js 파일이 로드되는지 확인
3. 브라우저 콘솔에서 에러 확인
4. 개발자 도구 → Sources 탭에서 파일 로드 확인
```

### 문제: 타이머가 계속 카운트다운됨
```
정상 동작입니다.
5분 (300초) 후 자동으로 초기화됩니다.
다시 인증하려면 "인증번호 전송" 클릭
```

---

## 📊 테스트 시나리오

### 시나리오 1: 정상 회원가입 (5분)
```
1. signup.jsp 접속
2. 모든 필수 필드 입력
3. 전화번호 인증 완료
4. selectRole.jsp에서 프리랜서 선택
5. complete-profile.jsp에서 프로필 입력
6. 기술 스택 선택 (3개 이상)
7. 제출
```

### 시나리오 2: 전화번호 변경 (3분)
```
1. 첫 번째 전화번호 입력 및 인증
2. 다른 전화번호로 변경
3. 경고 메시지 확인
4. 새 전화번호로 재인증
```

### 시나리오 3: 기술 스택 수정 (2분)
```
1. 기술 3개 선택
2. 각 기술의 숙련도/경력 입력
3. 모달 다시 열기
4. 기술 1개 제거, 새로운 기술 추가
5. 확인 클릭
6. 변경사항 반영 확인
```

---

## 🚀 배포 체크리스트

### Before Deployment
- [ ] 로컬 환경에서 모든 테스트 통과
- [ ] 브라우저 콘솔 에러 없음
- [ ] 모든 API 엔드포인트 작동 확인
- [ ] 데이터베이스 연결 확인

### During Deployment
- [ ] 파일 복사 확인
  - [ ] signup.jsp
  - [ ] signup.js
  - [ ] complete-profile.jsp
  - [ ] tech-stack-modal.jsp
  - [ ] tech-stack-modal.js
- [ ] 데이터베이스 마이그레이션 실행
- [ ] 캐시 초기화

### After Deployment
- [ ] 프로덕션 환경에서 테스트
- [ ] 모니터링 시작
- [ ] 에러 로그 확인
- [ ] 사용자 피드백 수집

---

## 📞 연락처 및 지원

### 버그 리포트
```
파일: issues.md 또는 이슈 트래커
형식:
  - 문제 설명
  - 재현 단계
  - 예상 동작
  - 실제 동작
  - 스크린샷
```

### 기술 지원
```
담당자: [개발팀]
이메일: [이메일 주소]
Slack: [채널]
```

---

## 📚 추가 자료

- [PHONE_AUTH_IMPLEMENTATION_GUIDE.md](PHONE_AUTH_IMPLEMENTATION_GUIDE.md) - 상세 구현 가이드
- [FREELANCER_PROFILE_MODAL_GUIDE.md](FREELANCER_PROFILE_MODAL_GUIDE.md) - 모달 기술 가이드
- [COMPLETE_IMPLEMENTATION_REPORT.md](COMPLETE_IMPLEMENTATION_REPORT.md) - 전체 구현 보고서

---

**버전**: 1.0
**최종 업데이트**: 2024년
**상태**: 테스트 가능 ✅
