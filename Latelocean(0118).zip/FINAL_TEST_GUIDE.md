# 🧪 최종 통합 테스트 가이드

## 📱 테스트 시나리오 1: 정상 회원가입 (5분)

### 준비
```
브라우저: Chrome 또는 Firefox
개발자 도구: F12 (콘솔 모니터링용)
URL: http://localhost:8080/ratelocean/join/signup.do
```

### 단계별 테스트

#### Step 1: 로그인 ID 입력 및 중복확인
```
입력: "testuser123"
클릭: "중복확인" 버튼
결과: 
  ✅ 콘솔에 AJAX 요청 보임
  ✅ "✓ 사용 가능한 ID입니다." 메시지
  ✅ validation.loginId = true
  ✅ "다음으로" 버튼 활성화도 진행
```

#### Step 2: 이메일 입력 및 중복확인
```
입력: "test@example.com"
클릭: "중복확인" 버튼
결과:
  ✅ "✓ 사용 가능한 이메일입니다." 메시지
  ✅ validation.email = true
```

#### Step 3: 비밀번호 입력
```
입력: "password123"
조건: 6자 이상
결과:
  ✅ validation.password = true
  ✅ 비밀번호 확인 입력 가능
```

#### Step 4: 비밀번호 확인
```
입력: "password123" (동일)
결과:
  ✅ validation.passwordConfirm = true
  
입력: "password124" (다름)
결과:
  ❌ validation.passwordConfirm = false
  ❌ "다음으로" 버튼 비활성화
```

#### Step 5: 이름 입력
```
입력: "홍길동"
결과:
  ✅ validation.fullName = true (2자 이상)
  
입력: "가"
결과:
  ❌ validation.fullName = false (1자)
```

#### Step 6: 생년월일 입력
```
입력: "2000.01.01"
```

#### Step 7: 📱 전화번호 인증
```
입력: "010-1234-5678"
결과: 올바른 형식
  ✅ "인증번호 전송" 버튼 클릭 가능

클릭: "인증번호 전송"
결과:
  ✅ "verify-area" 표시됨
  ✅ 타이머 시작: 5:00 → 4:59 → ...
  ✅ phoneAuthState.isCodeSent = true
  ✅ 콘솔에 "🔐 테스트용 인증번호: XXXXXX" 출력

콘솔 명령:
  console.log(phoneAuthState.verificationCode)
  
결과: 6자리 숫자 확인 (예: 654321)

입력: 위에서 확인한 숫자 입력
클릭: "확인" 버튼
결과:
  ✅ "✓ 인증이 완료되었습니다." 메시지
  ✅ validation.phoneVerified = true
  ✅ 모든 입력 필드 비활성화 (재입력 방지)
  ✅ "인증번호 전송" 버튼 비활성화
```

#### Step 8: 프리랜서 추가 정보
```
닉네임: "freelancer_name"
자기소개: "안녕하세요. 경험 많은 개발자입니다."
GitHub URL: "https://github.com/username" (선택)
웹사이트: "https://myportfolio.com" (선택)
```

#### Step 9: 계좌 정보 입력
```
은행: "KB국민은행" 선택
계좌번호: "12345678901234" 입력
  ⚠️ 숫자 이외의 문자 입력 시 자동으로 제거됨
  입력: "123-456-789*012" → 자동 변환 → "123456789012"

예금주: "홍길동" (이름과 동일하게)
  ⚠️ 이름과 다르면 확인 팝업 나타남
```

#### Step 10: 폼 제출
```
클릭: "다음으로" 버튼

콘솔 확인:
  📝 폼 제출: {
    loginId: "testuser123",
    email: "test@example.com",
    fullName: "홍길동",
    phone: "010-1234-5678",
    phoneVerified: true,
    bankName: "KB국민은행",
    accountNumber: "****8901234",
    accountHolder: "홍길동"
  }

결과:
  ✅ 폼 제출 (POST /join/signup.do)
  ✅ selectRole.jsp로 리다이렉트 (예상)
```

---

## 👥 테스트 시나리오 2: 프리랜서 프로필 완성 (7분)

### 준비
```
URL: http://localhost:8080/ratelocean/freelancer/complete-profile.do
(signup 완료 후 자동으로 이동)
```

### 단계별 테스트

#### Step 1: 닉네임 입력
```
입력: "freelancer_profile"
결과:
  ✅ 2자 이상 입력 가능
  
입력: "a" (1자)
클릭: "프로필 완성하기"
결과:
  ❌ 에러: "⚠️ 닉네임을 입력해주세요."
```

#### Step 2: 자기소개 입력
```
입력: "저는 5년 경력의 백엔드 개발자입니다. Java와 Spring을 잘 다룹니다."
최소: 10자 이상

입력: "짧은 소개" (9자)
클릭: "프로필 완성하기"
결과:
  ❌ 에러: "⚠️ 자기소개는 10자 이상이어야 합니다."
```

#### Step 3: 학력 정보 입력 (선택)
```
학교명: "서울대학교"
전공: "컴퓨터공학"
학위: "학사"
졸업 상태: "졸업"
```

#### Step 4: 경력 사항 추가 (선택)
```
클릭: "+ 경력 추가"

결과:
  ✅ 경력 입력 필드 생성
  
입력:
  회사명: "ABC 회사"
  역할: "백엔드 개발자"
  포지션: "시니어 개발자"
  시작일: "2020-01-15"
  종료일: "2023-12-31"
  업무 내용: "마이크로서비스 개발..."

여러 개 추가:
  클릭: "+ 경력 추가" 여러 번
  결과: 경력 1, 경력 2, ... 추가됨
  
삭제:
  각 경력의 "삭제" 버튼 클릭
  결과: 해당 경력 제거
```

#### Step 5: 프로젝트 경험 추가 (선택)
```
클릭: "+ 프로젝트 경험 추가"

입력:
  프로젝트명: "전자상거래 플랫폼"
  클라이언트: "XYZ 회사"
  역할: "풀스택 개발"
  시작일: "2023-01-01"
  종료일: "2023-06-30"
  설명: "Spring Boot와 React를 이용한..."

결과:
  ✅ 프로젝트 경험 항목 생성
```

#### Step 6: 포트폴리오 추가 (선택)
```
클릭: "+ 포트폴리오 추가"

입력:
  제목: "AI 채팅 봇"
  URL: "https://github.com/user/ai-chatbot"
  설명: "OpenAI API를 활용한..."

결과:
  ✅ 포트폴리오 항목 생성
```

#### Step 7: 🔧 기술 스택 선택 (필수!)
```
클릭: "🔍 기술 스택 선택 (모달)"

결과:
  ✅ 모달 창 열림
  ✅ 기술 목록 로드됨

기술 선택:
  ☑ Java
  ☑ Spring Boot
  ☑ React
  ☑ MySQL
  ☑ Docker
  
  (3개 이상 선택해야 함)

클릭: "확인" 버튼

결과:
  ✅ 모달 닫힘
  ✅ 선택된 기술이 태그로 표시됨:
    Java | Lv.3 • 1년 | ✕
    Spring Boot | Lv.3 • 1년 | ✕
    React | Lv.3 • 1년 | ✕
    MySQL | Lv.3 • 1년 | ✕
    Docker | Lv.3 • 1년 | ✕
  
  ✅ 각 기술 아래에 숚련도/경력 입력 폼 표시됨
```

#### Step 8: 기술 스택 숚련도 및 경력 수정
```
각 기술별로:
  숚련도: 1~5 선택
    1 = 초급
    2 = 초중급
    3 = 중급
    4 = 중상급
    5 = 전문가
  
  경력: 숫자 입력 (0.5년 단위 가능)
    예: 1, 1.5, 2, 2.5, ...

변경 결과:
  ✅ 태그가 실시간으로 업데이트됨
    Java | Lv.5 • 3년 | ✕
    ...

기술 삭제:
  태그의 "✕" 버튼 클릭
  결과:
    ✅ 태그 제거
    ✅ 입력 폼도 제거
    ⚠️ 경고: 1개 이상은 필수
```

#### Step 9: 계좌 정보 입력
```
은행: "신한은행"
계좌번호: "12345678901234"
예금주: "홍길동"
```

#### Step 10: 폼 제출
```
클릭: "프로필 완성하기"

검증:
  ✅ 모든 필수 필드 확인
  ✅ 기술 스택 1개 이상 확인
  ✅ 각 기술 숚련도/경력 확인

콘솔 확인:
  ✅ 프로필 폼 제출: {
    skillCount: 5,
    skills: [
      { id: 1, name: "Java", level: 5, years: 3 },
      ...
    ]
  }

결과:
  ✅ 폼 제출 (POST /freelancer/complete-profile.do)
  ✅ skills_json 숨겨진 필드에 JSON 전달
  ✅ 대시보드로 리다이렉트 (예상)
```

---

## ⚠️ 에러 케이스 테스트

### 에러 1: 필수 필드 미입력
```
액션: "다음으로" 또는 "프로필 완성하기" 버튼 클릭 (필드 비어있을 때)

결과:
  ✅ 에러 메시지 표시
  ✅ 폼 제출 안 됨
  ✅ 해당 필드로 자동 스크롤 (일부)
```

### 에러 2: 형식 검증 실패
```
전화번호: "010-123-456" (잘못된 형식)
결과:
  ❌ "올바른 전화번호 형식입니다." 메시지
  ❌ "인증번호 전송" 버튼 클릭 불가

계좌번호: "ABC-DEF-GHI" (숫자 아님)
결과:
  ✅ 자동으로 "ABC", "DEF", "GHI" 제거됨
  ✅ 빈 필드 남음
```

### 에러 3: 타이머 만료
```
액션: "인증번호 전송" 후 5분 대기 (또는 테스트)

결과:
  ✅ 타이머: 5:00 → 0:01 → 0:00
  ✅ 타이머 도달 시 자동 초기화
  ✅ "❌ 인증 시간이 만료되었습니다." 메시지
  ✅ "인증번호 전송" 버튼 다시 활성화
  ✅ 인증 영역 숨겨짐
```

### 에러 4: 전화번호 변경 후 재인증
```
액션:
  1. 첫 번째 전화번호 인증 완료
  2. 전화번호 필드 수정
  3. 새로운 전화번호 입력

결과:
  ✅ "⚠️ 전화번호가 변경되었습니다. 재인증이 필요합니다." 메시지
  ✅ 인증 상태 초기화
  ✅ "인증번호 전송" 버튼 다시 활성화
  ✅ 인증 영역 숨겨짐
```

---

## 🔍 개발자 도구 확인 사항

### Console 탭
```javascript
// 1. 전화번호 인증 상태 확인
console.log(phoneAuthState);
// 출력:
// {
//   currentPhone: "010-1234-5678",
//   verificationCode: "654321",
//   timerInterval: 123,
//   timeRemaining: 298,
//   isCodeSent: true,
//   isVerified: true
// }

// 2. 검증 상태 확인
console.log(validation);
// 출력:
// {
//   loginId: true,
//   email: true,
//   password: true,
//   passwordConfirm: true,
//   fullName: true,
//   phone: true,
//   phoneVerified: true
// }

// 3. 기술 스택 확인
console.log(selectedSkills);
// 출력:
// [
//   { id: 1, name: "Java", level: 5, years: 3 },
//   { id: 2, name: "React", level: 4, years: 2 },
//   ...
// ]

// 4. 폼 제출 시 메시지
// 📝 폼 제출: { ... }
// 📝 프로필 폼 제출: { ... }
```

### Network 탭
```
POST /join/check-loginid
  Request: { loginId: "testuser123" }
  Response: { available: true }

POST /join/check-email
  Request: { email: "test@example.com" }
  Response: { available: true }

POST /join/signup.do
  Request: FormData { ... }
  Response: 302 Redirect

POST /join/select-role.do
  Request: FormData { role: "freelancer" }
  Response: 302 Redirect

POST /freelancer/complete-profile.do
  Request: FormData { skills_json: "[...]", ... }
  Response: 302 Redirect or 200 Success
```

### Elements/Inspector 탭
```html
<!-- 전화번호 인증 영역 (초기: display:none) -->
<div id="verify-area" style="display:none">
  <input id="verify-code-input" />
  <button id="verify-code-btn">확인</button>
  <span id="verify-timer">5:00</span>
</div>

<!-- 인증 후 변경 -->
<div id="verify-area" style="display:flex">
  <input id="verify-code-input" disabled />
  <button id="verify-code-btn" disabled>확인</button>
  <span id="verify-timer">0:00</span>
</div>

<!-- 기술 스택 선택 후 -->
<div id="selected-skills-display">
  <div class="skill-tag-wrapper">
    <div class="skill-tag">
      <span class="skill-tag-name">Java</span>
      <span class="skill-tag-details">
        <span>Lv.5</span>
        <span>•</span>
        <span>3년</span>
      </span>
      <span class="skill-tag-remove">×</span>
    </div>
    ...
  </div>
</div>
```

---

## ✅ 최종 체크리스트

### 회원가입 페이지
- [ ] 모든 필드 입력 가능
- [ ] ID 중복확인 작동
- [ ] 이메일 중복확인 작동
- [ ] 전화번호 형식 검증 작동
- [ ] 인증번호 생성 및 전송 작동
- [ ] 타이머 카운트다운 작동
- [ ] 인증 완료 후 필드 비활성화
- [ ] 계좌번호 숫자만 입력
- [ ] 폼 제출 성공

### 프로필 페이지
- [ ] 모든 필드 입력 가능
- [ ] 동적 필드(repeater) 추가/삭제 작동
- [ ] 기술 스택 모달 열기/닫기 작동
- [ ] 기술 선택 및 추가 작동
- [ ] 기술 숚련도/경력 수정 작동
- [ ] 기술 삭제 작동
- [ ] 폼 검증 정상 작동
- [ ] 폼 제출 성공

### 개발자 도구
- [ ] Console 로그 정상 출력
- [ ] Network 요청/응답 확인
- [ ] 숨겨진 필드 생성 확인
- [ ] JSON 직렬화 정상 작동

### 에러 처리
- [ ] 필드 미입력 시 에러 메시지
- [ ] 형식 오류 시 에러 메시지
- [ ] 중복값 입력 시 에러 메시지
- [ ] 에러 시 폼 제출 안 됨

---

**테스트 작성일**: 2024년 1월
**상태**: 테스트 준비 완료 🟢
**다음 단계**: 서버 구현 후 통합 테스트

